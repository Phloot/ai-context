# Repository integration handoff

## Design

This is a small, greenfield component because the relevant repository was unavailable.
The command and SDK boundaries use the same SQL policy.
The target module resolves configuration before the SQL module loads its parser.
There is no database client, network call, LLM call, SQL rewrite, or automatic approval cache.

Four production modules divide the current responsibilities:

1. Event parsing and command output.
2. Target inventory and resolution.
3. SQL syntax review.
4. SDK subprocess handling.

The initial estimate was these four modules plus focused tests.
The SQL module is approximately 200 lines because it owns the complete rule set and parsed-tree traversal.
Do not split its rules across generic helper modules only to meet a line threshold.

## Native command contract

Use the native camelCase `preToolUse` event.
The script reads `toolName` and `toolArgs` from one JSON object on stdin.
It accepts an argument object and also handles a JSON-string argument value.
It does not consume the PascalCase event's `tool_name` and `tool_input` fields.

For reviewed calls, stdout contains exactly one JSON decision object.
The supported values are `allow`, `deny`, and `ask`.
A denial includes a static `permissionDecisionReason` and exits with status `2`.
An allow or ask exits with status `0`.
Unrelated and known non-production calls produce no output and exit with status `0`.
No result modifies tool arguments.

The SDK callback returns the same decision object, or `None` for pass-through.

## Verify the tool identity

These exact aliases are supported by the script:

- `postgres_db.run_query`
- `postgres_db-run_query`
- `postgres_db__run_query`
- `mcp__postgres_db__run_query`

These are explicit integration aliases, not a guarantee about your host's naming convention.
Inspect your host's actual tool identity using synthetic input in a disposable environment.
If the name differs, update `QUERY_TOOLS` and add a scope test before deployment.
Do not use a suffix match for every tool named `run_query`.
Do not add bare `run_query` without evidence that the event also identifies the server unambiguously.

## Verify target resolution

Inspect the implementation of `run_query(database, sql, max_rows=500)`.
Record exactly how `database` selects the connection.
If it is a database name on one fixed host, map each accepted name to that host and port.
If it is a connection alias, map that alias to its configured connection.

The policy supports exact aliases and single-host PostgreSQL URIs.
It rejects keyword connection strings and URI parameters that could override routing.
It preserves database-name case and normalizes only endpoint host and port representation.

Do not add guessed production-name patterns.
Do not classify an unknown target as non-production.
Keep production aliases and actual host/database mappings outside versioned source.

## Add the SDK callback

Copy `integrations/sdk_hook.py` beside the installed `postgres_query_hook.py`.
Add that trusted installation directory to your application's import path.
Import the callback factory:

```python
from sdk_hook import make_pre_tool_use

query_hook = make_pre_tool_use(
    python_executable="/absolute/path/to/postgres-query-venv/bin/python",
    hook_script="/absolute/path/to/hooks/scripts/postgres_query_hook.py",
    policy_file="/absolute/path/to/postgres-query-policy.json",
    allow_ask=False,
)
```

Register `query_hook` under `hooks["on_pre_tool_use"]` when creating and resuming sessions.
Adapt the call signature to your pinned SDK version.
Keep the application's existing permission handler.
Do not copy an `approve_all` example from generic SDK documentation.

If an existing pre-tool callback is present, compose the callbacks in the application.
A denial must win. A pending confirmation must not become an allow.
Do not let another callback rewrite the database or SQL after the policy check.
If the host supports argument rewriting, review the final arguments before dispatch.

The adapter runs the analyzer in a child process with a three-second deadline.
It returns deny for a timeout, missing executable, invalid response, or failed child process.
Known unrelated tool names return `None` before process creation.
The adapter defaults ask decisions to deny until the host has verified interactive approval.

Choose one registration path for each session to avoid duplicate review and prompts.
Do not assume user-level JSON files are automatically loaded by every SDK session.
Verify callback registration directly.

## Preserve existing server behavior

Do not change the server's username restriction or read-only transaction behavior.
Do not add SQL execution, schema queries, or credential reads to this hook.
Keep `list_schemas`, `list_tables`, and `describe_table` outside SQL review.

Keep the hook independent from maintainability context generation.
Reuse repository installation and command conventions only where their lifecycle contracts match.
A context-injection hook is not evidence that pre-tool denial is implemented correctly.

## Integrate the catalog

Open the existing maintainability hook manifest and catalog schema.
Map the example manifest's fields into the established schema.
Rename the example only after validation succeeds.
The example manifest is deliberately not presented as schema-valid for the unavailable repository.

The entry should describe purpose, source paths, installation, dependencies, decisions, and limitations.
Declare `pglast==8.4` as a local dependency.
Keep generated `catalog/catalog.json` and `catalog/schema/catalog-output.schema.json` under CI ownership.
Do not edit generated catalog output manually.

## Privacy

The implementation has no audit log.
Its messages use fixed rule identifiers and fixed explanations.
It does not echo parser errors, query text, literals, selectors, credentials, or connection strings.

The parent Copilot or MCP host can still log tool arguments independently.
Review that host's diagnostic settings before testing with real data.
If audit records are required, record only rule identifiers, decision, and a non-sensitive timestamp.
Do not store raw tool events as test fixtures.
