# Sources and implementation choices

Sources were checked on September 22, 2026.
Pin your deployed versions and repeat the contract checks after upgrades.

## Copilot contracts

- [GitHub Copilot hooks reference](https://docs.github.com/en/copilot/reference/hooks-reference)
- [Using hooks with Copilot CLI](https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/use-hooks)
- [SDK pre-tool use hook](https://docs.github.com/en/copilot/how-tos/copilot-sdk/hooks/pre-tool-use)

The CLI registration uses `preToolUse` and native `toolName`/`toolArgs` fields.
The decision object uses `permissionDecision` with `allow`, `deny`, or `ask`.
The command adapter emits no decision for pass-through.
The Python SDK adapter is registered under `on_pre_tool_use` and returns `None` for pass-through.

User-level hook JSON files belong in the configured Copilot hooks directory.
The default is `~/.copilot/hooks`; `COPILOT_HOME` changes that base.
Command-hook timeout behavior can proceed through normal permissions.
Therefore, this package treats the hook as an additional review layer.

The exact MCP tool aliases remain deployment-specific and require live verification.

## Parser comparison

| Option | Assessment | Decision |
| --- | --- | --- |
| [pglast](https://pglast.readthedocs.io/en/latest/) | PostgreSQL syntax tree through libpg_query; local Python API; native package dependency. | Selected and pinned to 8.4. |
| [libpg_query](https://github.com/pganalyze/libpg_query) | PostgreSQL parser extracted for use outside the server. | Used indirectly through pglast. |
| [SQLGlot](https://github.com/tobymao/sqlglot) | Multi-dialect parser and transpiler with PostgreSQL support. | More dialect machinery than this narrow PostgreSQL hook needs. |
| [sqlparse](https://sqlparse.readthedocs.io/en/latest/) | Non-validating tokenizer and formatting library. | Insufficient for reliable nested-statement policy checks. |
| Small keyword or regex engine | No dependency, but comments, literals, nested queries, and CTEs complicate reliable decisions. | Rejected for SQL classification. |

The selected parser ran locally and reported PostgreSQL parser version 18.4.
The adapter uses typed AST nodes to preserve child node types throughout traversal.
It does not rely on statement prefixes or raw JSON fields that omit some child-node wrappers.

If the server uses another PostgreSQL version, test representative queries against both parser and server.
A parser accepting syntax does not prove the server accepts it.
Do not silently replace a missing parser with keyword checks.

## PostgreSQL behavior

- [Read-only transaction behavior](https://www.postgresql.org/docs/current/sql-set-transaction.html)
- [EXPLAIN and ANALYZE](https://www.postgresql.org/docs/current/sql-explain.html)
- [Schemas and search paths](https://www.postgresql.org/docs/current/ddl-schemas.html)

Read-only transactions remain necessary but do not prove that every possible SELECT is harmless or inexpensive.
EXPLAIN ANALYZE executes its statement, so the hook blocks it.
Object resolution and search-path privileges remain server responsibilities.
