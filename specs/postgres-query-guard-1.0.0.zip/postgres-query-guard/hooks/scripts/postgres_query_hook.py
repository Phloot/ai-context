#!/usr/bin/env python3
"""Copilot preToolUse command boundary; stdin JSON to one stdout decision."""

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pg_query_policy.targets import load_config, resolve_target


# Exact integration aliases, not a suffix match. Verify the actual name at rollout.
QUERY_TOOLS = frozenset({
    "postgres_db.run_query", "postgres_db-run_query",
    "postgres_db__run_query", "mcp__postgres_db__run_query",
})
MAX_EVENT_BYTES = 262144


def decision(action, reason):
    return {"permissionDecision": action, "permissionDecisionReason": reason}


def tool_name(event):
    if not isinstance(event, dict):
        raise ValueError()
    # This adapter deliberately targets the native camelCase contract.
    name = event.get("toolName")
    if not isinstance(name, str) or not name:
        raise ValueError()
    return name


def review_event(event, config_path=None):
    try:
        if tool_name(event) not in QUERY_TOOLS:
            return None
        args = event.get("toolArgs")
        if isinstance(args, str):
            args = json.loads(args)
        if not isinstance(args, dict) or "database" not in args:
            return decision("deny", "ARGUMENTS: Supply database and SQL using the run_query argument schema.")
        path = config_path or os.environ.get("POSTGRES_QUERY_POLICY")
        if not path:
            path = Path(os.environ.get("COPILOT_HOME", Path.home() / ".copilot")) / "postgres-query-policy.json"
        try:
            inventory = load_config(path)
        except Exception:
            return decision("deny", "CONFIG: Provide a valid private PostgreSQL target inventory and policy.")
        try:
            target = resolve_target(args["database"], inventory)
        except Exception:
            return decision("deny", "TARGET: The database target is unknown or ambiguous. Verify the private inventory and server mapping.")
        if target["environment"] == "nonproduction":
            return None
        if set(args) - {"database", "sql", "max_rows"}:
            return decision("deny", "ARGUMENTS: Production calls accept only database, sql, and max_rows.")
        from pg_query_policy.sql_review import review_sql
        action, reason = review_sql(args.get("sql"), args.get("max_rows", 500), inventory[0], target["database"])
        return decision(action, reason)
    except Exception:
        # Do not log exceptions: parser and JSON errors can include secrets or literals.
        return decision("deny", "HOOK_INPUT: The hook could not validate this event. Check the installed hook contract.")


def main():
    try:
        data = sys.stdin.buffer.read(MAX_EVENT_BYTES + 1)
        if len(data) > MAX_EVENT_BYTES:
            result = decision("deny", "EVENT_SIZE: The hook event exceeds the supported input limit.")
        else:
            result = review_event(json.loads(data))
    except Exception:
        result = decision("deny", "HOOK_INPUT: Supply one valid native preToolUse JSON event.")
    if result is not None:
        print(json.dumps(result, separators=(",", ":")))
    return 2 if result and result["permissionDecision"] == "deny" else 0


if __name__ == "__main__":
    sys.exit(main())
