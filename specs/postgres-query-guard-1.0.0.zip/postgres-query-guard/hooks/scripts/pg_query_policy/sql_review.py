"""Conservative syntax policy. It cannot estimate cost or resolve database objects."""

from .targets import integer


FUNCTIONS = frozenset({
    "pg_catalog.count", "pg_catalog.min", "pg_catalog.max", "pg_catalog.sum",
    "pg_catalog.avg", "pg_catalog.lower", "pg_catalog.upper", "pg_catalog.length",
    "pg_catalog.date_trunc", "pg_catalog.now",
})
TYPES = frozenset({
    "bool", "int2", "int4", "int8", "numeric", "float4", "float8", "text",
    "varchar", "bpchar", "date", "timestamp", "timestamptz", "interval", "uuid",
    "json", "jsonb",
})
OPERATORS = frozenset({"=", "<>", "!=", "<", ">", "<=", ">=", "+", "-", "*", "/", "%", "~~", "!~~", "~~*", "!~~*", "->", "->>"})
APPROVED_NODES = frozenset({
    "SelectStmt", "ResTarget", "ColumnRef", "String", "A_Expr", "A_Const",
    "BoolExpr", "NullTest", "BooleanTest", "CaseExpr", "CaseWhen",
    "CoalesceExpr", "MinMaxExpr", "RangeVar", "JoinExpr", "RangeSubselect",
    "WithClause", "CommonTableExpr", "SubLink", "FuncCall", "TypeCast",
    "TypeName", "SortBy", "WindowDef", "A_Star", "A_Indirection",
    "A_Indices", "A_ArrayExpr", "RowExpr", "GroupingSet", "Alias", "Integer", "Float", "Boolean", "BitString",
})


def normalized_ast(value):
    """Keep every node type, including typed child fields omitted by raw JSON."""
    from enum import Enum
    from pglast.ast import Node
    if isinstance(value, Node):
        fields = {key: normalized_ast(getattr(value, key)) for key in value if getattr(value, key) is not None}
        return {type(value).__name__: fields}
    if isinstance(value, (tuple, list)):
        return [normalized_ast(item) for item in value]
    if isinstance(value, Enum):
        return value.name
    return value


def nodes(tree):
    pending = [tree]
    while pending:
        value = pending.pop()
        if isinstance(value, list):
            pending.extend(value)
        elif isinstance(value, dict):
            for name, body in value.items():
                yield name, body
                pending.append(body)


def names(parts):
    return ".".join(part["String"]["sval"] for part in parts)


def literal_integer(node):
    if not isinstance(node, dict):
        return None
    return node.get("A_Const", {}).get("val", {}).get("Integer", {}).get("ival")


def has_simple_filter(node):
    """Recognize a column/literal predicate, not selectivity or index usability."""
    if not isinstance(node, dict):
        return False
    if "BoolExpr" in node:
        body = node["BoolExpr"]
        args = body.get("args", [])
        results = [has_simple_filter(arg) for arg in args]
        if body.get("boolop") == "AND_EXPR":
            return any(results)
        if body.get("boolop") == "OR_EXPR":
            return bool(results) and all(results)
        return False
    body = node.get("A_Expr", {})
    if body.get("kind") != "AEXPR_OP" or names(body.get("name", [])) not in {"=", "<>", "!=", "<", ">", "<=", ">="}:
        return False
    left, right = body.get("lexpr", {}), body.get("rexpr", {})
    return ("ColumnRef" in left and "A_Const" in right) or ("ColumnRef" in right and "A_Const" in left)


def unwrap_select(statement):
    if "ExplainStmt" in statement:
        explain = statement["ExplainStmt"]
        for option in explain.get("options", []):
            body = option["DefElem"]
            if body.get("defname") != "format" or body.get("arg", {}).get("String", {}).get("sval") not in ("text", "json"):
                return None
        statement = explain["query"]
    return statement.get("SelectStmt")


def prohibited_node(name, body, database):
    if name.endswith("Stmt") and name != "SelectStmt":
        return "STATEMENT: Use one SELECT, optionally with read-only CTEs or plain EXPLAIN."
    if name == "SelectStmt" and (body.get("intoClause") or body.get("lockingClause")):
        return "WRITE_OR_LOCK: Remove SELECT INTO and row-locking clauses."
    if name == "SelectStmt" and body.get("valuesLists"):
        return "QUERY_FORM: VALUES queries are outside the approved query subset."
    if name == "WithClause" and body.get("recursive"):
        return "RECURSIVE: Recursive queries are outside the approved query forms."
    if name == "RangeVar" and body.get("catalogname", database) != database:
        return "DATABASE_MISMATCH: Remove the cross-database reference and verify the target."
    if name == "FuncCall" and names(body["funcname"]) not in FUNCTIONS:
        return "FUNCTION: Use an approved, pg_catalog-qualified function."
    if name in {"RangeFunction", "RangeTableFunc", "TableFunc", "RangeTableSample", "SQLValueFunction", "CollateClause", "XmlExpr"}:
        return "QUERY_FORM: This SQL form is outside the approved query subset."
    if name == "TypeName":
        parts = names(body.get("names", [])).split(".")
        if parts[-1] not in TYPES or (len(parts) > 1 and parts[:-1] != ["pg_catalog"]):
            return "TYPE: Use a supported built-in PostgreSQL type."
    if name == "A_Expr" and body.get("name") and names(body["name"]) not in OPERATORS:
        return "OPERATOR: Use a supported built-in operator."
    if name == "SelectStmt" and body.get("limitOption") == "LIMIT_OPTION_WITH_TIES":
        return "WITH_TIES: Use a fixed LIMIT without WITH TIES."
    if name[:1].isupper() and name not in APPROVED_NODES:
        return "QUERY_FORM: This SQL form is outside the approved query subset."
    return None


def review_sql(sql, max_rows, config, database):
    """Return (allow|deny|ask, static reason) without echoing any SQL content."""
    if not isinstance(sql, str) or not sql.strip() or len(sql.encode("utf-8")) > 65536:
        return "deny", "SQL_INPUT: Supply non-empty SQL within the 64 KiB limit."
    if not integer(max_rows, 1, config["max_rows"]):
        return "deny", "MAX_ROWS: Set max_rows to a positive integer within the configured cap."
    try:
        from pglast import parse_sql
        statements = parse_sql(sql)
    except ImportError:
        return "deny", "PARSER: Install the pinned parser in the hook Python environment."
    except Exception:
        return "deny", "SQL_PARSE: Rewrite the query as supported PostgreSQL SQL."
    if len(statements) != 1:
        return "deny", "STATEMENT_COUNT: Submit exactly one SELECT statement."
    query = unwrap_select(normalized_ast(statements[0].stmt))
    if query is None:
        return "deny", "STATEMENT: Use SELECT or EXPLAIN with only an optional FORMAT TEXT/JSON."
    tree = {"SelectStmt": query}
    all_nodes = list(nodes(tree))
    for name, body in all_nodes:
        reason = prohibited_node(name, body, database)
        if reason:
            return "deny", reason
    # max_rows is a fetch cap; it does not substitute for a SQL LIMIT.
    if any(name in {"RangeVar", "RangeSubselect"} for name, _ in all_nodes):
        if "limitCount" not in query:
            return "deny", "LIMIT: Add a literal top-level LIMIT within max_rows and the policy cap."
    review = set()
    for name, body in all_nodes:
        if name == "SelectStmt":
            if "limitCount" in body:
                limit = literal_integer(body["limitCount"])
                if not integer(limit, 1, min(max_rows, config["max_rows"])):
                    return "deny", "LIMIT: Every LIMIT must be a positive literal within max_rows and the policy cap."
            if "limitOffset" in body and not integer(literal_integer(body["limitOffset"]), 0, config["max_offset"]):
                return "deny", "OFFSET: Use a literal OFFSET within the policy cap, or use keyset pagination."
            if body.get("fromClause") and not has_simple_filter(body.get("whereClause")):
                review.add("FILTER_REVIEW")
            if body.get("op", "SETOP_NONE") != "SETOP_NONE" or body.get("groupClause") or body.get("distinctClause") or body.get("windowClause") or body.get("sortClause"):
                review.add("COST_REVIEW")
        if name in {"JoinExpr", "SubLink"} or (name == "fromClause" and len(body) > 1):
            review.add("COST_REVIEW")
        if name == "FuncCall" and (names(body["funcname"]) in {"pg_catalog.count", "pg_catalog.sum", "pg_catalog.avg", "pg_catalog.min", "pg_catalog.max"} or body.get("over")):
            review.add("COST_REVIEW")
        if name == "ColumnRef" and any("A_Star" in part for part in body["fields"]):
            review.add("PROJECTION_REVIEW")
    if review:
        return config["review_action"], ",".join(sorted(review)) + ": Confirm the filter, selected columns, and execution cost for this call."
    return "allow", "BOUNDED_READ: The query meets the configured syntax policy."
