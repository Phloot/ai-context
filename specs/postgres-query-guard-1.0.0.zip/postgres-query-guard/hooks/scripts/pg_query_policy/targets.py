"""Resolve server database selectors through an operator-owned inventory."""

import ipaddress
import json
import re
from pathlib import Path
from urllib.parse import unquote, urlsplit


class PolicyError(ValueError):
    """Invalid configuration or input; callers must not print exception details."""


def integer(value, minimum, maximum):
    return type(value) is int and minimum <= value <= maximum


def host_key(value):
    if not isinstance(value, str) or not value or value != value.strip():
        raise PolicyError()
    value = value.rstrip(".").lower()
    try:
        return ipaddress.ip_address(value).compressed
    except ValueError:
        if not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", value):
            raise PolicyError() from None
        return value


def target_key(host, port, database):
    if not integer(port, 1, 65535):
        raise PolicyError()
    if not isinstance(database, str) or not database or database != database.strip():
        raise PolicyError()
    return host_key(host), port, database


def load_config(path):
    with Path(path).expanduser().open(encoding="utf-8") as stream:
        config = json.load(stream)
    required = {"version", "targets", "max_rows", "max_offset", "review_action"}
    if not isinstance(config, dict) or set(config) != required or type(config["version"]) is not int or config["version"] != 1:
        raise PolicyError()
    if not integer(config["max_rows"], 1, 10000) or not integer(config["max_offset"], 0, 10000):
        raise PolicyError()
    if config["review_action"] not in ("ask", "deny"):
        raise PolicyError()
    if not isinstance(config["targets"], list) or not config["targets"]:
        raise PolicyError()
    aliases, endpoints = {}, {}
    for target in config["targets"]:
        fields = {"aliases", "host", "port", "database", "environment"}
        if not isinstance(target, dict) or set(target) != fields:
            raise PolicyError()
        if target["environment"] not in ("production", "nonproduction"):
            raise PolicyError()
        key = target_key(target["host"], target["port"], target["database"])
        if key in endpoints:
            raise PolicyError()
        endpoints[key] = target
        if not isinstance(target["aliases"], list) or not target["aliases"]:
            raise PolicyError()
        for alias in target["aliases"]:
            if not isinstance(alias, str) or not re.fullmatch(r"[A-Za-z0-9_.-]+", alias) or alias in aliases:
                raise PolicyError()
            aliases[alias] = target
    return config, aliases, endpoints


def resolve_target(value, inventory):
    """Aliases are exact; URI hosts normalize, database names retain case."""
    _, aliases, endpoints = inventory
    if not isinstance(value, str) or not value or value != value.strip():
        raise PolicyError()
    if value in aliases:
        return aliases[value]
    uri = urlsplit(value)
    if uri.scheme not in ("postgres", "postgresql") or not uri.hostname:
        raise PolicyError()
    # Query parameters can override host/dbname, route through services, or set options.
    # Reject them rather than partially interpreting libpq connection semantics.
    if uri.query or uri.fragment or "," in uri.netloc or not uri.path.startswith("/"):
        raise PolicyError()
    database = unquote(uri.path[1:], errors="strict")
    if not database or "/" in database or "\x00" in database:
        raise PolicyError()
    key = target_key(uri.hostname, 5432 if uri.port is None else uri.port, database)
    if key not in endpoints:
        raise PolicyError()
    return endpoints[key]
