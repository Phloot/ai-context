---
name: postgres-production-query
description: Prepare and review bounded PostgreSQL production reads through postgres_db.run_query. Use for production data investigations, query review, or a denial from the PostgreSQL query hook. Resolve the target, inspect metadata, reduce query scope, and respond to policy decisions without bypassing the hook. Do not apply this workflow to unrelated tools or known non-production calls.
---

# PostgreSQL production query

Prepare the smallest query that answers the user's question. Treat the hook as an additional review layer. Preserve database permissions and read-only transactions.

Read [references/policy.md](references/policy.md) for supported query forms and decision rules.

## Establish the target

1. Identify the database selector from the request and available server configuration.
2. Verify the selector against the operator-owned target inventory.
3. Confirm that the inventory matches the MCP server's actual host, port, and database mapping.
4. If the target is unknown or ambiguous, stop before execution and request the missing target information.

Do not infer the environment from a name that contains `prod`, `prd`, `dev`, or `test`.
Do not request passwords, tokens, or complete connection strings.
For a known non-production target, follow the normal tool workflow without this production review.

## Prepare a production read

1. Identify the question, required columns, and smallest useful result set.
2. Use `list_schemas`, `list_tables`, or `describe_table` when metadata is missing.
3. Select explicit columns.
4. Add a filter tied to the investigation, such as a known identifier or a narrow time range.
5. Add a positive literal SQL `LIMIT` within the configured cap.
6. Set `max_rows` to the same limit unless the tool requires a larger fetch cap.
7. Check each CTE and subquery for writes, unbounded work, and unnecessary data access.
8. Submit the query through the exposed `postgres_db.run_query` tool.

Use a supported `pg_catalog`-qualified function when a function is necessary.
Do not add an arbitrary filter only to satisfy the hook.
If the task requires a broad scan or aggregate, explain why and follow the review decision.

The SQL limit caps returned rows. It does not cap scanned rows, memory, or execution time.
The `max_rows` argument is a fetch cap. It does not replace SQL `LIMIT`.

## Respond to the hook

| Decision | Action |
| --- | --- |
| Allow | Continue through the existing permission flow. Describe the result and any truncation. |
| Ask | Let the host obtain approval for this exact call. State the scope and reason for review. |
| Deny | Explain the rule. Revise the query without changing the user's goal, or request the missing information. |
| No decision | Continue the normal workflow. This is expected for unrelated and known non-production calls. |

If interactive approval is unavailable, leave a review-required query blocked.
Do not treat earlier approval as permission for a changed query or different database.
Do not repeat a denied call unchanged.
Do not change the policy, rename the tool, or use another SQL surface to evade a denial.

## Review execution cost

For a justified complex read, consider plain `EXPLAIN` with optional `FORMAT JSON`.
The hook still reviews the underlying SELECT.
Do not use `EXPLAIN ANALYZE`; it executes the query.
Do not claim a query is inexpensive because the hook allowed it.

Check indexes, data volume, joins, sorting, and database timeouts when that information is available.
Report uncertainty when you cannot assess these properties.

## Protect diagnostic output

Do not repeat passwords, tokens, connection strings, or query literal values in hook diagnostics.
Use rule identifiers when explaining a denial.
Do not save complete tool payloads or production results in evaluation fixtures.
Use synthetic values for examples and tests.

## Complete the task

State the answer, database label when appropriate, applied scope, and whether the result might be incomplete.
Distinguish observed results from assumptions.
If execution was blocked, state the blocking rule and the smallest useful next action.
