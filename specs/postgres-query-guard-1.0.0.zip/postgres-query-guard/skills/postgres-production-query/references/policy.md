# Production query policy

This reference describes version 1.0.0 of the accompanying hook.
The skill guides the agent. The hook makes deterministic syntax decisions without an LLM or a database connection.

## Target policy

The private inventory maps exact selectors to a host, port, database, and environment.
Database names and selectors retain case. URI hostnames normalize to lowercase without a trailing dot.
An omitted URI port becomes `5432`. IPv6 addresses normalize to their compressed form.

| Input | Result |
| --- | --- |
| Known production selector or exact normalized endpoint | Review SQL. |
| Known non-production selector or endpoint | Pass through without SQL review. |
| Unknown selector or endpoint | Deny until the inventory is corrected. |
| URI query parameters, fragments, multiple hosts, or libpq keyword strings | Deny as unsupported target formats. |
| Missing, invalid, or conflicting inventory | Deny intercepted query calls. Other named tools pass through. |

The inventory must reflect the server's real resolution rules.
The hook cannot discover a host from a database name alone.
URI support in the hook does not add URI support to the MCP server.
Do not replace a valid server selector with a URI unless the server accepts that form.

## Decision rules

| Condition | Decision |
| --- | --- |
| One bounded SELECT with explicit columns and a recognized filter | Allow under the syntax policy. |
| Read-only CTEs and subqueries | Apply checks throughout the parsed tree. |
| Plain EXPLAIN or EXPLAIN with FORMAT TEXT/JSON | Apply the same checks to its SELECT. |
| Multiple statements, writes, DDL, COPY, CALL, DO, transaction commands | Deny. |
| Data-changing CTE, SELECT INTO, row lock, recursive CTE | Deny. |
| EXPLAIN option other than FORMAT TEXT/JSON, including ANALYZE false | Deny. |
| Different database qualifier in a relation reference | Deny. |
| Unapproved function, custom type, operator, or AST node | Deny. |
| Table read without a top-level literal SQL LIMIT | Deny. |
| LIMIT ALL, expression limit, zero limit, negative limit, or WITH TIES | Deny. |
| Any explicit limit above max_rows or the configured cap | Deny. |
| Invalid max_rows or OFFSET above the configured cap | Deny. |
| Missing or unrecognized filter in any SELECT with FROM | Review. |
| SELECT star projection | Review. |
| Join, aggregate, subquery expression, set operation, sort, grouping, DISTINCT, or window | Review. |
| Unparseable SQL or unavailable parser | Deny production calls. |

The default policy maps **review** to deny.
Set `review_action` to `ask` only after the host's approval path passes the live checks.
An SDK deployment also requires `allow_ask=True` in the supplied adapter.
Approval must cover the exact pending call. Do not implement approval by changing the SQL or disabling the hook.

## Default limits

- Result cap: 500 rows.
- Offset cap: 1,000 rows.
- SQL input: 64 KiB.
- Serialized command event: 256 KiB.
- SDK child-process deadline: 3 seconds.
- Command hook host timeout: 10 seconds.

A missing `max_rows` uses the server default of 500 from the supplied description.
If the policy cap is lower, the caller must supply a lower `max_rows`.

## Recognized filters

Automatic allow recognizes a direct column-to-literal comparison with `=`, `<>`, `!=`, `<`, `>`, `<=`, or `>=`.
An AND expression needs one recognized branch. An OR expression needs all branches recognized.
Other predicates, including `IN`, `IS NULL`, function calls, casts, and parameter references, do not establish this filter check.
Parameter references are blocked because this tool contract has no parameter binding argument.

This check detects predicate shape. It does not prove selectivity or an index match.
A predicate such as `id > 0` can still match most rows.
A self-comparison or `WHERE TRUE` requires review.
CTEs can require review when an outer SELECT has no recognized filter, even if the inner SELECT is bounded.

## Approved functions

Use these exact function names:

- `pg_catalog.count`, `pg_catalog.min`, `pg_catalog.max`, `pg_catalog.sum`, `pg_catalog.avg`
- `pg_catalog.lower`, `pg_catalog.upper`, `pg_catalog.length`
- `pg_catalog.date_trunc`, `pg_catalog.now`

Aggregates require cost review. `COUNT(*)` is not treated as a star projection.
Unqualified names and application-defined functions are blocked.
Function allowlisting reduces risk but does not resolve overloads or argument types.

## Examples

Bounded lookup, subject to the private target inventory:

```sql
SELECT id, status
FROM public.orders
WHERE id = 42
LIMIT 20;
```

Bounded aggregate that requires cost review:

```sql
SELECT pg_catalog.count(*) AS total
FROM public.orders
WHERE id > 1000
LIMIT 1;
```

## Enforcement limits

Keep the server's username guard and read-only transactions.
Use a database role with only the required access.
Configure statement and lock timeouts on the server or database role.

The parser does not resolve views, foreign tables, row-level security, overloaded operators, casts, or implicit function calls.
Use a trusted search path and restrict privileges to create database objects.
The hook cannot guarantee that a read is cheap, free of side effects, or appropriate for a data classification.
A LIMIT does not cap the work inside a join, sort, aggregate, or CTE.

The hook covers only its exact tool-name aliases.
It does not intercept shell SQL clients, other MCP servers, or an outer tool that hides another tool call.
Missing registration, disabled hooks, and unsupported hosts leave this review layer inactive.
Copilot command-hook timeouts can continue through the normal permission flow.
Keep server controls as the enforcement boundary.
