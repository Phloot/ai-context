"""Register the returned callback as hooks['on_pre_tool_use'] in Copilot SDK."""

import asyncio
import json
import os
from pathlib import Path

from postgres_query_hook import QUERY_TOOLS, tool_name

def make_pre_tool_use(python_executable, hook_script, policy_file, *, allow_ask=False):
    """Use a child deadline shorter than the host deadline. Default review to deny."""
    python_executable = str(Path(python_executable).expanduser().absolute())
    hook_script = str(Path(hook_script).expanduser().resolve())
    policy_file = str(Path(policy_file).expanduser().resolve())

    async def on_pre_tool_use(input_data, invocation):
        del invocation
        failure = {"permissionDecision": "deny", "permissionDecisionReason": "HOOK_FAILURE: The local query policy could not complete."}
        process = None
        try:
            if tool_name(input_data) not in QUERY_TOOLS:
                return None
            payload = json.dumps(input_data).encode("utf-8")
            process = await asyncio.create_subprocess_exec(
                python_executable, "-I", hook_script,
                stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
                env={**os.environ, "POSTGRES_QUERY_POLICY": policy_file},
            )
            stdout, _ = await asyncio.wait_for(process.communicate(payload), timeout=3)
            if process.returncode not in (0, 2):
                return failure
            if not stdout.strip():
                return None if process.returncode == 0 else failure
            result = json.loads(stdout)
            if not isinstance(result, dict) or result.get("permissionDecision") not in {"allow", "deny", "ask"}:
                return failure
            if process.returncode == 2 and result["permissionDecision"] != "deny":
                return failure
            if result["permissionDecision"] == "ask" and not allow_ask:
                result = {**result, "permissionDecision": "deny"}
                result["permissionDecisionReason"] += " Interactive approval is not enabled in this adapter."
            return result
        except Exception:
            return failure
        finally:
            if process is not None and process.returncode is None:
                try:
                    process.kill()
                except ProcessLookupError:
                    pass
                await process.wait()

    return on_pre_tool_use
