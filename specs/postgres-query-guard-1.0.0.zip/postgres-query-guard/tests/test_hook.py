"""Behavior and process contracts. No PostgreSQL or Copilot connection is used."""

import asyncio
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "hooks/scripts"))
sys.path.insert(0, str(ROOT / "integrations"))
from postgres_query_hook import QUERY_TOOLS, review_event
from sdk_hook import make_pre_tool_use

SAFE_SQL = "SELECT id FROM public.orders WHERE id = 42 LIMIT 20"


def event(sql=SAFE_SQL, database="orders-prod", max_rows=500):
    return {"toolName": "postgres_db.run_query", "toolArgs": {
        "database": database, "sql": sql, "max_rows": max_rows,
    }}


class HookTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.config_path = Path(self.directory.name) / "policy.json"
        self.config = json.loads((ROOT / "config/postgres-query-policy.example.json").read_text())
        self.config["review_action"] = "ask"
        self.save()

    def save(self):
        self.config_path.write_text(json.dumps(self.config))

    def review(self, payload):
        return review_event(payload, self.config_path)

    def assertDecision(self, payload, action, code=None):
        result = self.review(payload)
        self.assertEqual(result["permissionDecision"], action, result)
        if code:
            self.assertIn(code, result["permissionDecisionReason"])
        return result

    def test_exact_tool_scope_and_silent_pass_through(self):
        self.config_path.unlink()
        for tool in ["bash", "postgres_db.list_schemas", "postgres_db.list_tables", "postgres_db.describe_table", "other.run_query", "run_query", "evil.postgres_db.run_query"]:
            with self.subTest(tool=tool):
                self.assertIsNone(self.review({"toolName": tool, "toolArgs": "not JSON"}))

    def test_supported_aliases(self):
        for tool in QUERY_TOOLS:
            payload = event()
            payload["toolName"] = tool
            self.assertDecision(payload, "allow")

    def test_arguments_as_object_and_serialized_json(self):
        payload = event()
        self.assertDecision(payload, "allow")
        payload["toolArgs"] = json.dumps(payload["toolArgs"])
        self.assertDecision(payload, "allow")

    def test_native_fixture_contract(self):
        paths = sorted((ROOT / "tests/fixtures").glob("*.json"))
        self.assertTrue(paths, "Contract fixtures must be present")
        for path in paths:
            fixture = json.loads(path.read_text())
            with self.subTest(fixture=path.name):
                result = self.review(fixture["input"])
                if fixture["expected"] == "pass":
                    self.assertIsNone(result)
                else:
                    self.assertEqual(result["permissionDecision"], fixture["expected"])

    def test_nonproduction_skips_sql_review(self):
        self.assertIsNone(self.review(event("not sql; DELETE FROM x", "orders-dev", -1)))

    def test_target_normalization_and_identity(self):
        for target in ["orders-production", "postgresql://person:PRIVATE@PROD-DB.EXAMPLE.INVALID.:5432/orders", "postgres://prod-db.example.invalid/orders"]:
            with self.subTest(target=target):
                self.assertDecision(event(database=target), "allow")
        for target in ["unknown", "ORDERS-PROD", " orders-prod", "orders-prod ", "postgres://prod-db.example.invalid:0/orders", "postgres://dev-db.example.invalid/Orders", "postgres://prod-db.example.invalid/orders?host=dev-db.example.invalid", "host=prod-db.example.invalid dbname=orders", "postgres://dev-db.example.invalid:5433/orders"]:
            with self.subTest(target=target):
                self.assertDecision(event(database=target), "deny", "TARGET")

    def test_ipv6_and_percent_encoded_database(self):
        self.config["targets"][0]["host"] = "2001:db8::1"
        self.config["targets"][0]["database"] = "Orders Live"
        self.save()
        self.assertDecision(event(database="postgresql://[2001:db8:0:0::1]/Orders%20Live"), "allow")

    def test_bad_inventory_blocks_query_but_not_other_tools(self):
        original = copy.deepcopy(self.config)
        variants = [
            {**original, "max_rows": True},
            {**original, "targets": original["targets"] * 2},
            {**original, "review_action": "allow"},
            {**original, "typo": 1},
        ]
        for config in variants:
            self.config = config
            self.save()
            self.assertDecision(event(), "deny", "CONFIG")
            self.assertIsNone(self.review({"toolName": "bash"}))
        self.config_path.write_text("not JSON")
        self.assertDecision(event(), "deny", "CONFIG")
        self.config_path.unlink()
        self.assertDecision(event(), "deny", "CONFIG")

    def test_approved_queries(self):
        for sql in [SAFE_SQL, "SELECT 1", "SELECT 'delete; drop table' AS example", "SELECT id::int FROM public.orders WHERE id=42 LIMIT 20", "SELECT id FROM orders WHERE id=42 FETCH FIRST 20 ROWS ONLY", "EXPLAIN (FORMAT JSON) " + SAFE_SQL, "WITH x AS (SELECT id FROM orders WHERE id=42 LIMIT 20) SELECT id FROM x WHERE id=42 LIMIT 20", "SELECT id FROM orders WHERE id=42 AND status IS NOT NULL LIMIT 20"]:
            with self.subTest(sql=sql):
                self.assertDecision(event(sql), "allow")

    def test_prohibited_queries(self):
        cases = [
            ("DELETE FROM orders", "STATEMENT"),
            ("SELECT 1; SELECT 2", "STATEMENT_COUNT"),
            ("WITH x AS (DELETE FROM orders RETURNING id) SELECT id FROM x LIMIT 20", "STATEMENT"),
            ("SELECT id INTO TEMP scratch FROM orders LIMIT 20", "WRITE_OR_LOCK"),
            (SAFE_SQL + " FOR UPDATE", "WRITE_OR_LOCK"),
            ("WITH RECURSIVE x AS (SELECT 1 UNION ALL SELECT 2) SELECT * FROM x LIMIT 20", "RECURSIVE"),
            ("EXPLAIN ANALYZE " + SAFE_SQL, "STATEMENT"),
            ("EXPLAIN (ANALYZE false) " + SAFE_SQL, "STATEMENT"),
            ("SELECT pg_sleep(5)", "FUNCTION"),
            ("SELECT pg_catalog.pg_read_file('/etc/passwd')", "FUNCTION"),
            ("SELECT public.count(*) FROM orders LIMIT 20", "FUNCTION"),
            ("SELECT count(*) FROM orders LIMIT 20", "FUNCTION"),
            ("SELECT dblink('PRIVATE', 'select 1')", "FUNCTION"),
            ("SELECT id FROM another.public.orders WHERE id=42 LIMIT 20", "DATABASE_MISMATCH"),
            ("SELECT id FROM orders WHERE id=42", "LIMIT"),
            ("SELECT id FROM orders LIMIT ALL", "LIMIT"),
            ("SELECT id FROM orders LIMIT (SELECT 20)", "LIMIT"),
            ("SELECT id FROM orders LIMIT 0", "LIMIT"),
            ("SELECT id FROM orders LIMIT 501", "LIMIT"),
            ("SELECT id FROM (SELECT id FROM orders LIMIT 501) x WHERE id=42 LIMIT 20", "LIMIT"),
            ("SELECT id FROM orders WHERE id=1 UNION SELECT id::public.custom FROM orders WHERE id=2 LIMIT 20", "TYPE"),
            ("SELECT id FROM orders LIMIT 20 OFFSET 1001", "OFFSET"),
            ("SELECT id FROM orders ORDER BY id FETCH FIRST 20 ROWS WITH TIES", "WITH_TIES"),
            ("SELECT id::public.custom FROM orders WHERE id=1 LIMIT 20", "TYPE"),
            ("SELECT * FROM generate_series(1,1000000) LIMIT 20", None),
            ("VALUES (1), (2)", "QUERY_FORM"),
            ("SELECT $1", "QUERY_FORM"),
            ("SELECT id FROM orders WHERE id OPERATOR(public.=) 1 LIMIT 20", "OPERATOR"),
            ("SELECT FROM", "SQL_PARSE"),
        ]
        for sql, code in cases:
            with self.subTest(sql=sql):
                self.assertDecision(event(sql), "deny", code)

    def test_reviewable_queries(self):
        queries = [
            "SELECT id FROM orders LIMIT 20",
            "SELECT id FROM orders WHERE TRUE LIMIT 20",
            "SELECT id FROM orders WHERE id=id LIMIT 20",
            "SELECT id FROM orders WHERE id=42 OR TRUE LIMIT 20",
            "SELECT * FROM orders WHERE id=42 LIMIT 20",
            "SELECT pg_catalog.count(*) FROM orders WHERE id>0 LIMIT 20",
            "SELECT a.id FROM orders a JOIN items b ON a.id=b.id WHERE a.id=42 LIMIT 20",
            "SELECT id FROM orders WHERE id>42 ORDER BY id LIMIT 20",
            "SELECT id FROM orders WHERE id IN (1,2) LIMIT 20",
            "SELECT id FROM orders WHERE id=1 UNION SELECT id FROM orders WHERE id=2 LIMIT 20",
        ]
        for sql in queries:
            with self.subTest(sql=sql):
                self.assertDecision(event(sql), "ask")
        self.config["review_action"] = "deny"
        self.save()
        self.assertDecision(event(queries[0]), "deny", "FILTER_REVIEW")

    def test_bad_arguments_and_default_max_rows(self):
        for rows in [True, 0, -1, 501, "20", 20.0, None]:
            with self.subTest(rows=rows):
                self.assertDecision(event(max_rows=rows), "deny", "MAX_ROWS")
        self.assertDecision(event(max_rows=10), "deny", "LIMIT")
        payload = event()
        del payload["toolArgs"]["max_rows"]
        self.assertDecision(payload, "allow")
        payload["toolArgs"]["extra"] = True
        self.assertDecision(payload, "deny", "ARGUMENTS")
        for sql in [None, "", "x" * 65537]:
            self.assertDecision(event(sql), "deny", "SQL_INPUT")

    def test_no_secret_echo_in_diagnostics(self):
        secret = "SENSITIVE_VALUE_987654"
        for payload in [event("SELECT '" + secret), event(database="postgres://u:" + secret + "@unknown/db"), {"toolName": "postgres_db.run_query", "toolArgs": secret}]:
            result = self.review(payload)
            self.assertEqual(result["permissionDecision"], "deny")
            self.assertNotIn(secret, json.dumps(result))

    def run_command(self, payload, executable=None):
        return subprocess.run([executable or sys.executable, "-I", str(ROOT / "hooks/scripts/postgres_query_hook.py")], input=payload, capture_output=True, text=True, env={**os.environ, "POSTGRES_QUERY_POLICY": str(self.config_path)}, timeout=5)

    def test_process_exit_codes_and_silence(self):
        for payload, expected, code in [(event(), "allow", 0), (event("DELETE FROM orders"), "deny", 2), (event("SELECT id FROM orders LIMIT 20"), "ask", 0), ({"toolName": "bash"}, None, 0)]:
            result = self.run_command(json.dumps(payload))
            self.assertEqual(result.returncode, code, result.stderr)
            self.assertEqual(result.stderr, "")
            if expected is None:
                self.assertEqual(result.stdout, "")
            else:
                self.assertEqual(json.loads(result.stdout)["permissionDecision"], expected)
        for payload in ["{SECRET", json.dumps({"tool_name": "postgres_db.run_query"}), "x" * 262145]:
            result = self.run_command(payload)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(result.stderr, "")
            self.assertEqual(json.loads(result.stdout)["permissionDecision"], "deny")

    def test_missing_parser_blocks_production_only(self):
        # -S removes third-party site packages while preserving the installed script.
        script = str(ROOT / "hooks/scripts/postgres_query_hook.py")
        for payload, expected in [(event(), "deny"), (event(database="orders-dev"), None), ({"toolName": "bash"}, None)]:
            result = subprocess.run([sys.executable, "-I", "-S", script], input=json.dumps(payload), capture_output=True, text=True, env={**os.environ, "POSTGRES_QUERY_POLICY": str(self.config_path)}, timeout=5)
            self.assertEqual(result.stderr, "")
            if expected:
                self.assertIn("PARSER", json.loads(result.stdout)["permissionDecisionReason"])
            else:
                self.assertEqual(result.stdout, "")

    def test_sdk_adapter_against_real_child(self):
        hook = make_pre_tool_use(sys.executable, ROOT / "hooks/scripts/postgres_query_hook.py", self.config_path)
        self.assertEqual(asyncio.run(hook(event(), {}))["permissionDecision"], "allow")
        self.assertIsNone(asyncio.run(hook({"toolName": "bash"}, {})))
        query = event("SELECT id FROM orders LIMIT 20")
        self.assertEqual(asyncio.run(hook(query, {}))["permissionDecision"], "deny")
        interactive = make_pre_tool_use(sys.executable, ROOT / "hooks/scripts/postgres_query_hook.py", self.config_path, allow_ask=True)
        self.assertEqual(asyncio.run(interactive(query, {}))["permissionDecision"], "ask")

    def test_sdk_child_failure_and_deadline(self):
        fake = Path(self.directory.name) / "fake.py"
        for body in ["print('not JSON')", "raise SystemExit(1)", "import time; time.sleep(30)"]:
            fake.write_text(body)
            hook = make_pre_tool_use(sys.executable, fake, self.config_path)
            result = asyncio.run(hook(event(), {}))
            self.assertEqual(result["permissionDecision"], "deny")
            self.assertIn("HOOK_FAILURE", result["permissionDecisionReason"])
            self.assertIsNone(asyncio.run(hook({"toolName": "bash"}, {})))


if __name__ == "__main__":
    unittest.main()
