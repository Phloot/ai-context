# Evaluate Relay

Run these paths in order. Offline checks establish script behavior. Live checks establish model access. Host checks establish skill selection and interception. Paired tasks establish value. Passing one path does not establish the others.

## 1. Offline checks: no model calls

From the extracted relay directory:

```sh
python3 -m unittest discover -s tests -v
python3 skills/relay-reader/scripts/run.py --version
```

Expect all tests to pass and version 2.1.0. These tests do not prove macOS host discovery or model quality.

## 2. Prepare the installed reader

Flightlog must first install the reader and, for interception tests, the routing component. Replace the interpreter path below with its existing venv. Run these commands in the environment used by Copilot. Exported variables in this terminal do not automatically reach an already running GUI application.

```sh
export RELAY_PYTHON='/absolute/path/to/flightlog-venv/bin/python'
export RELAY_CONFIG="$HOME/.copilot/state/relay/settings.json"
mkdir -p "$(dirname "$RELAY_CONFIG")"
# First setup only: do not overwrite an existing user config.
test -f "$RELAY_CONFIG" || cp "$HOME/.copilot/skills/relay-reader/references/relay.json" "$RELAY_CONFIG"
python3 "$HOME/.copilot/skills/relay-reader/scripts/run.py" doctor --live
```

The live diagnostic lists model IDs and then reports that the placeholder is unavailable. Edit the JSON model field to the listed Luna 5.6 ID. Leave writer_model null. Set mode to observe for the first trial. If authentication fails, authenticate the Copilot runtime using your organization's supported login flow and repeat.

```sh
python3 "$HOME/.copilot/skills/relay-reader/scripts/run.py" doctor --smoke
python3 evals/run_live.py --runner "$HOME/.copilot/skills/relay-reader/scripts/run.py" > reader-results.json
```

The smoke check makes one paid request. The eval runner makes three paid reader requests and returns a nonzero exit code if an automated check fails. It tests defaults, cross-file comparison, and missing context. Open reader-results.json and inspect the answers, not just automated_check_passed. Correct evidence can accompany an incorrect claim; a nonempty limitations field alone does not prove that an answer avoided invention. These small fixtures test function, not cost savings.

## 3. Host behavior with known fixtures

Create disposable files from the extracted bundle directory:

```sh
mkdir -p /tmp/relay-trial
python3 - <<'PY'
from pathlib import Path
root = Path('/tmp/relay-trial')
(root / 'client.py').write_text('RETRIES = 3\nTIMEOUT_SECONDS = 10\n' + '# fixture padding\n' * 400)
(root / 'ClientConfig.java').write_text('final class ClientConfig {\n    static final int RETRIES = 2;\n}\n' + '// fixture padding\n' * 400)
PY
```

Start a fresh Copilot agent conversation with /tmp/relay-trial as its working project. Ensure it inherits the interpreter and config settings. First test explicit use:

> Use relay-reader to compare the retry defaults in client.py and ClientConfig.java. Pass the paths to the script without reading their full contents first. Return the values with evidence and report anything the files do not establish.

Expect Python 3 and Java 2, verified source evidence, and a script invocation. No full-file tool result should enter the main conversation. Then repeat in a fresh conversation without naming the skill:

> Compare the retry defaults in client.py and ClientConfig.java. Inspect the saved files and cite their definitions.

Record whether the skill is chosen autonomously. If ordinary bounded search answers it directly, that is also efficient behavior. Do not count the absence of delegation as a failure when delegation was unnecessary.

Next change mode to enforce in the config, retain the successful smoke marker, and reload the client. Ask:

> Read all of client.py using your native file-read tool.

Inspect host diagnostics for a Relay denial. Then ask for lines 1 through 20; that read should pass. A model that chooses Relay before making the native call does not prove hook interception. Record that outcome and use a controlled native-tool test supported by the host to verify the hook.

For CLI with IntelliJ MCP, repeat using the actual MCP file-read tool. Until the mapping in docs/TOMORROW.md is implemented, broad MCP reads can pass through. Record this as an uncovered path. In IntelliJ chat, verify skill use separately from hooks.

In a disposable IntelliJ buffer, change RETRIES to 7 without saving. Ask:

> What is the current retry value in my unsaved editor buffer? Use IntelliJ's buffer-aware tool.

Expect 7 from the IDE. Relay's disk reader must not be presented as evidence about that buffer. Discard the fixture edit afterward.

Also test the task boundary:

> Investigate whether this repository's retry and locking logic can race. Read the relevant implementation directly before drawing a conclusion.

Use a real representative repository. Expect the main agent to perform the reasoning with direct source, even if preliminary discovery used Relay. A bulk summary alone is insufficient.

## 4. Does it add value? Paired repository tasks

Choose at least ten factual discovery/comparison tasks with answers a developer can verify. Include large saved files and several small tasks. Add two debugging tasks to check that the agent keeps reasoning with the main model. Use the same commit and main model for every pair, without unsaved edits.

For each task run:

1. Baseline: disable Relay components through Flightlog, reload the client, and use a fresh conversation.
2. Relay: enable the reader/routing profile, reload, and use a fresh conversation with the identical prompt. For IntelliJ use the supported skill-only profile if hooks are unavailable.
3. Alternate which condition runs first. Repeat noisy cases. Include all retries and source verification needed to reach a correct answer.

Example prompts, replacing paths with actual repository paths:

> Compare timeout and retry defaults across src/main/java/.../Client.java and src/main/java/.../Config.java. Cite each definition. Distinguish configured defaults from runtime overrides that these files cannot establish.

> Identify which methods in services/client.py and services/transport.py call the transport API. Give exact names and source evidence. Do not infer behavior from method names alone.

> Locate the configuration controlling this feature, explain the precedence supported by the source, and identify anything requiring additional context.

Record one row per run:

| Task | Condition | Main/worker model IDs | Correct/complete | Unsupported claims | Total seconds | Billed units or cost | Main input/output tokens | Worker input/output tokens | Retries/direct reads |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| discovery-01 | baseline or Relay | actual IDs | review result | count/details | elapsed | actual or unavailable | actual or unavailable | actual or unavailable | count |

Use client/account usage records and worker diagnostics when available. Do not equate main-context reduction with billed savings. Include cached-token pricing, worker charges, failed attempts, and verification. If comparable usage records are unavailable, report context reduction and latency separately and leave financial value unproven. Relay metrics contain counts and timings, not a complete invoice. The live eval report contains answers and should remain internal.

Compute per-task total savings as (baseline cost minus Relay cost) divided by baseline cost, only when baseline cost is positive and units are comparable. Compare median completion time and correctness across the paired tasks. Do not generalize from one large-file example.

Suggested pilot gate, to adjust before running: no critical unsupported conclusions, no material reduction in correct/complete answers, at least 20% median total-cost reduction on the targeted large-read tasks, and a latency penalty the team explicitly accepts. Small tasks should normally avoid delegation. If cost is unavailable, do not claim the cost gate passed. If results fail, first narrow the eligible tasks or raise the threshold, then rerun the same cases. Disable the routing component if it adds friction without benefit.

## 5. Optional writer: separate experiment

The standard trial does not generate code. Leave writer_model null and keep ordinary code generation with the main agent. To evaluate the optional writer, explicitly configure a listed Opus 5 or GPT 5.6 Sol ID and enable its skill. It never inherits Luna from model.

```sh
python3 evals/run_live.py --runner "$HOME/.copilot/skills/relay-reader/scripts/run.py" --include-writer > reader-and-writer-results.json
```

This makes four calls: the three reader calls and one writer call using writer_model. Review generated_code in the report; the structural check is not a semantic test. For representative repository generation, compare against the same main-agent model, run focused repository tests, and count review/correction effort and total cost. A frontier worker may save main-context space without reducing total cost. Do not combine its results with the Luna reader trial.
