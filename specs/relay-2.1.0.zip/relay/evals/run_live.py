#!/usr/bin/env python3
"""Run three reader calls, with an optional fourth writer call. Use after doctor --smoke succeeds."""

import argparse
import ast
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path

PYTHON_SOURCE = '''from dataclasses import dataclass

@dataclass
class ClientConfig:
    retries: int = 3
    timeout_seconds: int = 10

def retry_count(config, override=None):
    if override is not None:
        return override
    return config.retries
'''

JAVA_SOURCE = '''final class ClientConfig {
    static final int RETRIES = 2;
    static final int TIMEOUT_SECONDS = 15;
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runner", type=Path, default=Path(__file__).resolve().parents[1] / "skills/relay-reader/scripts/run.py")
    parser.add_argument("--include-writer", action="store_true", help="Also evaluate the separately configured writer model")
    args = parser.parse_args()
    results = []
    with tempfile.TemporaryDirectory(prefix="relay-eval-") as directory:
        root = Path(directory)
        (root / "client.py").write_text(PYTHON_SOURCE)
        (root / "ClientConfig.java").write_text(JAVA_SOURCE)
        (root / "reference.py").write_text('def add(a: int, b: int) -> int:\n    """Add two integers."""\n    return a + b\n')
        cases = [
            ("python_defaults", ["read", "--question", "What are the retry and timeout defaults?", "--paths", "client.py"]),
            ("language_comparison", ["read", "--question", "Compare the retry defaults in the Python and Java files.", "--paths", "client.py", "ClientConfig.java"]),
            ("missing_context", ["read", "--question", "Which production caller overrides retry_count, and with what value? State if that is unknown.", "--paths", "client.py"]),
            ("new_python_file", ["write", "--spec", "Create multiply(a: int, b: int) -> int. Return a * b. Use the reference style. No other functions or imports.",
                                 "--reference", "reference.py", "--target", "multiply.py"]),
        ]
        if not args.include_writer:
            cases = cases[:3]
        for name, command in cases:
            started = time.monotonic()
            result = subprocess.run([sys.executable, str(args.runner.resolve()), *command, "--root", str(root)],
                                    text=True, capture_output=True)
            passed = result.returncode == 0
            answer = None
            if passed:
                answer = json.loads(result.stdout)
                evidence = "\n".join(f["evidence"] for f in answer.get("findings", []))
                if name == "python_defaults":
                    passed = "3" in evidence and "10" in evidence
                elif name == "language_comparison":
                    passed = {f["path"] for f in answer["findings"]} == {"client.py", "ClientConfig.java"} and "3" in evidence and "2" in evidence
                elif name == "missing_context":
                    passed = bool(answer["limitations"])
                else:
                    tree = ast.parse((root / "multiply.py").read_text())
                    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
                    passed = len(functions) == 1 and functions[0].name == "multiply"
            results.append({"case": name, "automated_check_passed": passed,
                            "seconds": round(time.monotonic() - started, 2),
                            "answer": answer, "diagnostics": result.stderr.strip()})
        # Preserve the generated code in the report for human review; do not execute it.
        if (root / "multiply.py").exists():
            results[-1]["generated_code"] = (root / "multiply.py").read_text()
    print(json.dumps(results, indent=2))
    return 0 if all(item["automated_check_passed"] for item in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
