#!/usr/bin/env python3
"""A standard-library-only hook; it never starts a model session."""

import json
import sys
import os
from pathlib import Path

root = Path(os.environ.get("COPILOT_HOME", Path(__file__).resolve().parents[3]))
sys.path.insert(0, str(root / "skills/relay-reader/scripts"))

try:
    from relay.routing import main
except Exception:
    print(json.dumps({}))
    sys.exit(0)

if __name__ == "__main__":
    raise SystemExit(main())
