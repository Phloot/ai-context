# Flightlog catalog handoff

Use ai-component-catalog as the source of the components. Keep its existing catalog.json schema. This bundle does not invent a replacement schema.

Register relay-reader as a skill and distribute its complete directory. Register relay-writer as a skill with relay-reader as a dependency. Register relay-routing as a hook with relay-reader as a dependency; distribute both hooks/relay-routing.json and hooks/relay-routing/scripts/hook.py.

Suggested profiles:

- Relay reader: reader plus routing hook, for CLI and VS Code after host verification.
- Relay skills: reader only, for IntelliJ or advisory trials.
- Relay generation (optional, excluded from default rollout): writer plus reader; configure writer_model separately. The routing hook is optional.

Flightlog handles toggles, dependency removal rules, file installation, and updates. The installed files operate independently of Flightlog. Preserve script-relative paths. The writer and hook reuse the reader's scripts; no agent component is needed because worker instructions are supplied by the Python helper.

Set the existing venv interpreter through RELAY_PYTHON in the client environment, or adapt the bundled launch commands to that interpreter. Supply RELAY_CONFIG when persistent user configuration must survive replacement. Do not install another SDK or modify the shared venv from this package.

Before release, verify the exact catalog mapping, the interpreter path, SDK API compatibility, SDK authentication, and hook discovery on the organization's client versions. For remote development, install the components and interpreter in the environment where the agent executes its tools.
