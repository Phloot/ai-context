# Validation record

Relay 2.1.0, September 10, 2026.

Offline tests cover source evidence, input limits, symlink escapes, new-file syntax and overwrite protection, worker isolation and cleanup, routing boundaries, malformed hook input, and distribution into paths with spaces. Hook outputs are checked for both CLI and VS Code denial envelopes. The distributed reader and writer launchers are exercised without an installer.

During the preceding implementation, SDK 1.0.13 source was inspected and runtime 1.0.83 was started on Linux. An isolated session was created, disconnected, and deleted without model inference. Disconnecting before deletion avoided an attached-session event-decoding failure. The revised package retains that worker lifecycle.

This environment has no authenticated Copilot account. Model inference, answer quality, billing savings, and actual IDE/CLI hook discovery are not verified. Native macOS execution is not verified; this is a macOS-targeted bundle tested on Linux. Current documentation lists JetBrains hooks as unsupported. The JSON supports documented host envelopes, but a fixture test is not proof that a particular client loads the hook.

Run doctor --smoke, the live evals, and the host read-interception check in the README before relying on automatic routing. No savings percentage is claimed.

Version 2.1.0 adds separate writer configuration, removes non-macOS shell support, and expands the skill workflow and evaluation procedures. Live evaluation is reader-only unless --include-writer is supplied.
