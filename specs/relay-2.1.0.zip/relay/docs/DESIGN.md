# Design

The hook examines a pending read. For recognized broad reads above the threshold, it returns a denial that names relay-reader. It permits no operation itself. The main agent invokes the skill script with paths and a question. The script reads the files into a separate SDK session and returns findings with verified evidence. Only that output enters the main conversation.

The optional writer uses the same worker helper. It requires a specification and reference files, validates the target before inference, then creates a new file exclusively. It cannot overwrite an existing file. The caller receives the path and validation status. The caller must review and test the result.

Hooks provide deterministic interception where supported. Skills provide instructions and remain advisory. Scripts provide file checks, SDK transport, result validation, and cleanup. Flightlog distributes all three and does not participate in execution.

The hook supplies both a flat Copilot CLI denial and a nested VS Code hookSpecificOutput denial. Client integration still requires a live host check. Unexpected events and hook errors defer to normal permissions. Worker sessions disable tools and discovery and also deny permission requests. The worker uses a temporary working directory and is disconnected before deletion to avoid a decoding issue observed with SDK 1.0.13.

Use the main agent for debugging, architectural judgment, edits, and small reads. A verified quote does not prove a correct conclusion. Measure the cost and latency of the complete task, including retries and verification reads.
