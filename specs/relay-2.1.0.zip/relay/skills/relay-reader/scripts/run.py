"""Run Relay with the interpreter supplied by the distribution environment."""
import os
import sys
from pathlib import Path

interpreter = os.environ.get("RELAY_PYTHON")
if interpreter and os.path.abspath(os.path.expanduser(interpreter)) != os.path.abspath(sys.executable):
    interpreter = os.path.expanduser(interpreter)
    os.execv(interpreter, [interpreter, str(Path(__file__).resolve()), *sys.argv[1:]])
if sys.version_info < (3, 11):
    sys.exit("Relay requires Python 3.11 or newer.")
from relay.cli import main
raise SystemExit(main())
