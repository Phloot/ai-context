"""Cost routing, not a security boundary. Never grants a permission."""

import json
import os
import shlex
import sys
from pathlib import Path

from . import config


def requested_lines(args):
    bounds = args.get("view_range")
    if bounds is None:
        start = args.get("startLine", args.get("start_line"))
        end = args.get("endLine", args.get("end_line"))
        if start is not None or end is not None:
            bounds = [start, end]
    if isinstance(bounds, list) and len(bounds) == 2:
        start, end = bounds
        if type(start) is int and type(end) is int and 1 <= start <= end:
            return end - start + 1
        return None
    limit = args.get("limit")
    if type(limit) is int and limit > 0:
        return limit
    return None  # An offset without a limit does not bound the response.


def shell_requests(command):
    """Recognize simple reads only; leave complex shell syntax to the client."""
    if not isinstance(command, str) or any(c in command for c in "|;&><`$\n"):
        return []
    try:
        parts = shlex.split(command)
    except ValueError:
        return []
    if not parts:
        return []
    tool = Path(parts.pop(0)).name.lower()
    if tool not in ("cat", "head", "tail", "less", "more"):
        return []
    count = 10 if tool in ("head", "tail") else None
    paths = []
    while parts:
        arg = parts.pop(0)
        lower = arg.lower()
        if lower in ("-n", "--lines"):
            if not parts or not parts[0].isdigit():
                return []
            count = int(parts.pop(0))
        elif tool in ("head", "tail") and arg.startswith("-n") and arg[2:].isdigit():
            count = int(arg[2:])
        elif tool in ("head", "tail") and arg.startswith("--lines=") and arg[8:].isdigit():
            count = int(arg[8:])
        elif arg == "--":
            continue
        elif arg.startswith("-"):
            return []  # Unsupported option: do not guess its semantics.
        else:
            paths.append((arg.strip("\"'"), count))
    # Options can follow paths; apply the final bounded count consistently.
    return [(path, count) for path, _ in paths]


def is_large(path, threshold):
    if not path.is_file():
        return False
    # Bound bytes as well as lines, including huge generated single-line files.
    with path.open("rb") as stream:
        data = stream.read(1_000_001)
    if b"\0" in data:
        return False
    return len(data) > 1_000_000 or len(data.splitlines()) > threshold


def decide(payload, settings):
    if settings["mode"] == "off" or os.environ.get("RELAY_WORKER") == "1":
        return {}
    if settings["mode"] == "enforce" and not config.ready(settings):
        return {}  # Activate only after doctor --smoke succeeds for this model.
    name = payload.get("toolName", payload.get("tool_name", ""))
    args = payload.get("toolArgs", payload.get("tool_input", {}))
    if isinstance(args, str):
        args = json.loads(args)
    if not isinstance(args, dict):
        return {}
    cwd = Path(payload.get("cwd") or Path.cwd()).resolve()
    requests = []
    if name in ("view", "Read", "read_file"):
        path = args.get("path", args.get("file_path", args.get("filePath")))
        if isinstance(path, str):
            requests = [(path, requested_lines(args))]
    elif settings["shell_reads"] and name in ("bash", "Bash"):
        requests = shell_requests(args.get("command"))
    large = []
    for value, limit in requests:
        if limit is not None and limit <= settings["min_lines"]:
            continue
        path = (cwd / value).resolve()
        # Do not inspect files outside the working directory for cost routing.
        if path.is_relative_to(cwd) and is_large(path, settings["min_lines"]):
            large.append(path)
    if not large:
        return {}
    config.record(settings, "route", mode=settings["mode"], tool=name, file_count=len(large))
    if settings["mode"] == "observe":
        return {}
    return {"permissionDecision": "deny", "permissionDecisionReason": (
        "Relay: broad read exceeds the configured threshold. Use the relay-reader skill "
        "with these file paths and a specific question; do not read and paste their contents. "
        "Bounded source reads remain available for verification and debugging. "
        "If full context is essential, use the skill's direct-read command with a reason. "
        "If the worker fails, use targeted reads; do not retry the same blocked call.")}


def main():
    try:
        raw = sys.stdin.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError("Hook input is too large")
        result = decide(json.loads(raw), config.load())
    except Exception:
        # Cost-routing failures must defer to existing client permissions.
        print("Relay hook could not classify this call; using normal permissions.", file=sys.stderr)
        result = {}
    if result.get("permissionDecision") == "deny":
        result["hookSpecificOutput"] = {"hookEventName": "PreToolUse", **result}
    print(json.dumps(result))
    return 0
