"""User configuration and content-free operational records."""

import json
import os
import time
from . import __version__
from pathlib import Path

DEFAULTS = {
    "model": "LUNA_MODEL_ID",
    "writer_model": None,
    "mode": "enforce",
    "min_lines": 350,
    "max_input_bytes": 200_000,
    "max_output_chars": 16_000,
    "timeout_seconds": 120,
    "shell_reads": True,
    "log_metrics": True,
}


def home():
    return Path(os.environ.get("COPILOT_HOME", Path.home() / ".copilot")).expanduser().resolve()


def state_dir():
    return home() / "state" / "relay"


def config_path():
    return Path(os.environ.get("RELAY_CONFIG", Path(__file__).resolve().parents[2] / "references" / "relay.json")).expanduser()


def load():
    path = config_path()
    settings = DEFAULTS.copy()
    if path.exists():
        supplied = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(supplied, dict) or supplied.keys() - DEFAULTS.keys():
            raise ValueError("Invalid relay config keys. Compare with references/relay.json.")
        settings.update(supplied)
    validate(settings)
    return settings


def validate(settings):
    if settings["mode"] not in ("off", "observe", "enforce"):
        raise ValueError("mode must be off, observe, or enforce")
    if not isinstance(settings["model"], str) or not settings["model"].strip():
        raise ValueError("model must be a nonempty model ID")
    writer = settings["writer_model"]
    if writer is not None and (not isinstance(writer, str) or not writer.strip()):
        raise ValueError("writer_model must be null or a nonempty model ID")
    for key in ("min_lines", "max_input_bytes", "max_output_chars", "timeout_seconds"):
        if type(settings[key]) is not int or settings[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    for key in ("shell_reads", "log_metrics"):
        if type(settings[key]) is not bool:
            raise ValueError(f"{key} must be true or false")


def save(settings):
    validate(settings)
    config_path().parent.mkdir(parents=True, exist_ok=True)
    path = config_path()
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def ready(settings):
    try:
        marker = json.loads((state_dir() / "ready.json").read_text(encoding="utf-8"))
        return marker == {"model": settings["model"], "relay": __version__}
    except (OSError, ValueError):
        return False


def mark_ready(settings):
    state_dir().mkdir(parents=True, exist_ok=True)
    (state_dir() / "ready.json").write_text(
        json.dumps({"model": settings["model"], "relay": __version__}), encoding="utf-8")


def record(settings, event, **fields):
    """Record counts and timings, never prompts, source, or model responses."""
    if not settings["log_metrics"]:
        return
    try:
        state_dir().mkdir(parents=True, exist_ok=True)
        path = state_dir() / "metrics.jsonl"
        if path.exists() and path.stat().st_size > 5_000_000:
            path.replace(path.with_suffix(".previous.jsonl"))
        line = json.dumps({"time": time.time(), "event": event, **fields}) + "\n"
        fd = os.open(path, os.O_CREAT | os.O_APPEND | os.O_WRONLY, 0o600)
        try:
            os.write(fd, line.encode("utf-8"))
        finally:
            os.close(fd)
    except OSError:
        pass  # A metrics failure must not break work.
