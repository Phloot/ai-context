"""Bounded source input and verifiable worker output."""

import ast
import hashlib
import json
from pathlib import Path


def read_sources(paths, root, max_bytes):
    root = Path(root).resolve()
    sources = []
    seen = set()
    remaining = max_bytes
    for value in paths:
        path = (root / value).resolve()
        if not path.is_relative_to(root):
            raise ValueError(f"File is outside --root: {value}")
        if path in seen:
            continue
        seen.add(path)
        if not path.is_file():
            raise ValueError(f"Not a regular file: {value}")
        with path.open("rb") as stream:
            raw = stream.read(remaining + 1)
        remaining -= len(raw)
        if remaining < 0:
            raise ValueError("Input exceeds max_input_bytes. Select fewer files.")
        if b"\0" in raw:
            raise ValueError(f"Binary input is not supported: {value}")
        text = raw.decode("utf-8-sig")
        sources.append({"path": path.relative_to(root).as_posix(), "text": text,
                        "sha256": hashlib.sha256(raw).hexdigest()})
    if not sources:
        raise ValueError("Supply at least one source file")
    return sources


def source_payload(sources):
    return [{"path": source["path"], "sha256": source["sha256"],
             "lines": [{"line": i, "text": line}
                       for i, line in enumerate(source["text"].splitlines(), 1)]}
            for source in sources]


def strip_fence(text):
    text = text.strip()
    lines = text.splitlines()
    if len(lines) >= 2 and lines[0].startswith("```") and lines[-1] == "```":
        return "\n".join(lines[1:-1]).strip()
    return text


def validate_answer(text, sources, max_chars):
    if len(text) > max_chars:
        raise ValueError("Worker answer exceeds max_output_chars; narrow the question")
    answer = json.loads(strip_fence(text))
    if not isinstance(answer, dict) or set(answer) != {"findings", "limitations"}:
        raise ValueError("Worker must return findings and limitations")
    findings, limitations = answer["findings"], answer["limitations"]
    if not isinstance(findings, list) or not isinstance(limitations, list):
        raise ValueError("findings and limitations must be lists")
    if not all(isinstance(item, str) for item in limitations):
        raise ValueError("Each limitation must be text")
    by_path = {source["path"]: source for source in sources}
    for item in findings:
        if not isinstance(item, dict) or set(item) != {"claim", "path", "start_line", "end_line", "evidence"}:
            raise ValueError("A finding has invalid fields")
        if not all(isinstance(item[k], str) for k in ("claim", "path", "evidence")):
            raise ValueError("Finding claim, path, and evidence must be text")
        source = by_path.get(item["path"])
        if source is None:
            raise ValueError("Worker cited a file that was not supplied")
        start, end = item["start_line"], item["end_line"]
        lines = source["text"].splitlines()
        if type(start) is not int or type(end) is not int or not 1 <= start <= end <= len(lines):
            raise ValueError("Worker cited an invalid line range")
        excerpt = "\n".join(lines[start - 1:end])
        if not item["evidence"].strip() or item["evidence"] not in excerpt:
            raise ValueError("Worker evidence does not match the cited source range")
        item["source_sha256"] = source["sha256"]
    return answer


def new_target(target, root):
    path = (Path(root).resolve() / target).absolute()
    # Do not resolve the final component: reject an existing symlink as well.
    if not path.parent.resolve().is_relative_to(Path(root).resolve()):
        raise ValueError("Target is outside --root")
    if path.exists() or path.is_symlink():
        raise ValueError("Target already exists. Use the main agent for edits.")
    if not path.parent.is_dir():
        raise ValueError("Target directory must already exist")
    return path


def write_new_file(text, target, root, max_chars):
    path = new_target(target, root)
    code = strip_fence(text)
    if not code or len(code) > max_chars:
        raise ValueError("Generated file is empty or exceeds max_output_chars")
    if path.suffix == ".py":
        ast.parse(code, filename=str(path))
    elif path.suffix == ".json":
        json.loads(code)
    # Exclusive creation protects an existing file if another process wins the race.
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(code + "\n")
    return {"target": str(path), "lines": len(code.splitlines()),
            "validation": "syntax checked" if path.suffix in (".py", ".json") else "not validated",
            "review_required": True}
