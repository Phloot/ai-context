"""Command workflows for reading, writing, diagnostics, and routing."""

import argparse
import asyncio
import importlib.metadata
import json
import sys
import time
from pathlib import Path

from . import __version__, config, files, routing, worker


def parser():
    result = argparse.ArgumentParser(description="Copilot Relay: small workers for large reads and new files")
    result.add_argument("--version", action="version", version=__version__)
    subs = result.add_subparsers(dest="command", required=True)
    read = subs.add_parser("read", help="Extract source-backed findings")
    read.add_argument("--question", required=True)
    read.add_argument("--paths", nargs="+", required=True)
    write = subs.add_parser("write", help="Generate one new file; never overwrite")
    spec = write.add_mutually_exclusive_group(required=True)
    spec.add_argument("--spec")
    spec.add_argument("--spec-file")
    write.add_argument("--reference", nargs="+", required=True)
    write.add_argument("--sources", nargs="*", default=[])
    write.add_argument("--target", required=True)
    direct = subs.add_parser("direct-read", help="Read exact source when a summary is unsuitable")
    direct.add_argument("--path", required=True)
    direct.add_argument("--reason", required=True)
    direct.add_argument("--start", type=int, default=1)
    direct.add_argument("--end", type=int)
    for sub in (read, write, direct):
        sub.add_argument("--root", default=".")
    for sub in (read, write):
        sub.add_argument("--model", help="Override the configured worker model")
    doctor = subs.add_parser("doctor", help="Check local installation and optional live model access")
    doctor.add_argument("--live", action="store_true", help="Authenticate and list available models")
    doctor.add_argument("--smoke", action="store_true", help="Run a small model check and activate routing")
    subs.add_parser("hook", help="Read a preToolUse event from stdin")
    return result


def run_worker(prompt, instructions, settings):
    try:
        text, metadata = asyncio.run(worker.invoke(prompt, instructions, settings))
    except (TimeoutError, asyncio.TimeoutError):
        raise ValueError("Worker timed out. Use targeted reads or a smaller request.") from None
    except (ImportError, ModuleNotFoundError):
        raise ValueError("SDK missing. Set RELAY_PYTHON to the existing Flightlog venv interpreter.") from None
    except ValueError:
        raise
    except Exception as exc:
        # SDK exception text can contain requests. Never echo it into the main context.
        raise ValueError(f"Worker failed ({type(exc).__name__}). Run doctor --live; use targeted reads meanwhile.") from None
    if not metadata["session_deleted"]:
        print("Relay: worker session cleanup failed; local Copilot session data may remain.", file=sys.stderr)
    return text, metadata


def delegate(args, settings):
    selected = args.model or (settings["writer_model"] if args.command == "write" else settings["model"])
    if not selected:
        raise ValueError("Relay writer is disabled. Configure writer_model separately or use the main agent for code generation.")
    settings = {**settings, "model": selected}
    config.validate(settings)
    started = time.monotonic()
    if args.command == "read":
        sources = files.read_sources(args.paths, args.root, settings["max_input_bytes"])
        payload = {"question": args.question, "files": files.source_payload(sources)}
        instructions = worker.READER
    else:
        files.new_target(args.target, args.root)
        sources = files.read_sources(args.reference + args.sources, args.root, settings["max_input_bytes"])
        spec = args.spec
        if args.spec_file:
            spec = files.read_sources([args.spec_file], args.root, settings["max_input_bytes"])[0]["text"]
        payload = {"spec": spec, "target": args.target,
                   "reference_paths": [(Path(args.root).resolve() / p).resolve().relative_to(Path(args.root).resolve()).as_posix()
                                       for p in args.reference],
                   "files": files.source_payload(sources)}
        instructions = worker.WRITER
    prompt = json.dumps(payload, ensure_ascii=False)
    if len(prompt.encode("utf-8")) > settings["max_input_bytes"] * 3:
        raise ValueError("Encoded request is too large. Select fewer files or shorten the question.")
    instructions += f"\nKeep output below {settings['max_output_chars']} characters."
    text, metadata = run_worker(prompt, instructions, settings)
    if args.command == "read":
        result = files.validate_answer(text, sources, settings["max_output_chars"])
    else:
        if text.strip() == "RELAY_NEEDS_CONTEXT":
            raise ValueError("Worker needs more context. Supply implementation sources and a clearer spec.")
        result = files.write_new_file(text, args.target, args.root, settings["max_output_chars"])
    config.record(settings, args.command, model=settings["model"], file_count=len(sources),
                  input_bytes=sum(len(s["text"].encode("utf-8")) for s in sources),
                  output_chars=len(text), seconds=round(time.monotonic() - started, 3))
    print(json.dumps(result, indent=2, ensure_ascii=False))
    print(json.dumps({"relay_worker": metadata}), file=sys.stderr)


def doctor(args, settings):
    try:
        sdk = importlib.metadata.version("github-copilot-sdk")
    except importlib.metadata.PackageNotFoundError:
        sdk = None
    report = {"relay": __version__, "python": sys.version.split()[0], "sdk": sdk,
              "sdk_tested": "1.0.13", "config": str(config.config_path()),
              "model": settings["model"], "writer_model": settings["writer_model"], "mode": settings["mode"],
              "routing_ready": config.ready(settings),
              "hook_installed": (config.home() / "hooks" / "relay-routing.json").is_file()}
    print(json.dumps(report, indent=2))
    if sdk is None:
        raise ValueError("Set RELAY_PYTHON to an interpreter with github-copilot-sdk installed")
    if not (args.live or args.smoke):
        return
    models = asyncio.run(worker.inspect_models(settings))
    print(json.dumps({"available_models": models}, indent=2))
    if settings["model"] not in models:
        raise ValueError("Configured model is unavailable. Set model in references/relay.json to an ID listed above.")
    if args.smoke:
        sources = [{"path": "fixture.py", "text": "RETRY_LIMIT = 3\n", "sha256": "smoke-fixture"}]
        prompt = json.dumps({"question": "What is RETRY_LIMIT? Cite its definition.",
                             "files": files.source_payload(sources)})
        text, _ = run_worker(prompt, worker.READER, settings)
        answer = files.validate_answer(text, sources, settings["max_output_chars"])
        if not answer["findings"] or not any("3" in f["evidence"] for f in answer["findings"]):
            raise ValueError("Smoke check did not return the expected evidence")
        config.mark_ready(settings)
        print("Smoke check passed. Routing is ready for the configured mode.")


def main(argv=None):
    args = parser().parse_args(argv)
    if args.command == "hook":
        return routing.main()
    try:
        settings = config.load()
        if args.command in ("read", "write"):
            delegate(args, settings)
        elif args.command == "doctor":
            doctor(args, settings)
        elif args.command == "direct-read":
            if not args.reason.strip():
                raise ValueError("Supply a reason for reading full source")
            source = files.read_sources([args.path], args.root, settings["max_input_bytes"])[0]
            lines = source["text"].splitlines()
            end = args.end if args.end is not None else len(lines)
            if not 1 <= args.start <= end <= len(lines):
                raise ValueError("Invalid line range")
            config.record(settings, "direct_read", line_count=end - args.start + 1)
            print("\n".join(f"{i}: {lines[i - 1]}" for i in range(args.start, end + 1)))
        return 0
    except (ValueError, OSError, UnicodeError, SyntaxError) as exc:
        print(f"Relay: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Relay cancelled.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"Relay failed ({type(exc).__name__}). Check authentication with doctor --live.", file=sys.stderr)
        return 1
