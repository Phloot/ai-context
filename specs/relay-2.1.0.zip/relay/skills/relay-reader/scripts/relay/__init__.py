"""Small workers and read routing for GitHub Copilot."""

__version__ = "2.1.0"
