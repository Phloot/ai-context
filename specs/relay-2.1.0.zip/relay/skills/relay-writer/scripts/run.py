"""Use the reader dependency's shared runtime."""
import os
import sys
from pathlib import Path

root = Path(os.environ.get("COPILOT_HOME", Path(__file__).resolve().parents[3]))
runner = root / "skills/relay-reader/scripts/run.py"
if not runner.is_file():
    sys.exit("Relay requires the relay-reader component. Enable its marketplace dependency.")
os.execv(sys.executable, [sys.executable, str(runner), *sys.argv[1:]])
