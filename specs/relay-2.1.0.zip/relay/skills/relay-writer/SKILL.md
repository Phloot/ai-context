---
name: relay-writer
description: Generate a predictable new code or configuration file through a separate Copilot worker, using a clear specification and existing reference files. Excludes edits, architectural decisions, and debugging.
---

# Relay writer

This optional worker is disabled until writer_model is configured separately.
Use the main agent for ordinary code generation. Never fall back to the reader model.
Use this worker only for a new file whose behavior and structure are already decided.
For test generation, decide the scenarios and assertions before delegation.
Supply implementation sources as well as a reference test file.
Do not delegate uncertainty about expected behavior.

Run the bundled `scripts/run.py` with Python 3.11 or newer.
Resolve the script relative to this skill's directory.
The launcher uses RELAY_PYTHON when set to the existing Flightlog venv interpreter.
Flightlog only installs these files; it does not need to be running.
The relay-reader dependency must be installed beside this skill.

```text
python3 <skill-directory>/scripts/run.py write --spec-file task-spec.txt --reference tests/test_client.py --sources src/service.py --target tests/test_service.py
```

Run from the repository root, or pass `--root` with the repository's absolute path.
Use `--spec` instead of `--spec-file` for a short specification.
Quote paths that contain spaces.
Do not read reference files merely to copy their contents into the request.
Do not change the configured worker model unless the user requests that change.

The target directory must exist. The target file must not exist.
The runner returns the target path and validation status, not the generated code.
Python and JSON receive syntax checks. Other file types need repository validation.

Run the relevant formatter, compiler, or focused tests after generation.
Inspect the generated behavior before claiming the task is complete.
A successful write is not evidence that the implementation is correct.
Use the main agent for corrections to existing files.

If the worker needs more context, supply the missing source or refine the specification.
If it fails, continue with the main agent. Do not repeatedly regenerate blindly.
Use only source and target paths authorized by the current task.
Preserve the repository's confidentiality and content-exclusion requirements when selecting inputs.
