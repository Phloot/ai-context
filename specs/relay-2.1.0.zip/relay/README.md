# Relay

This bundle targets macOS. See [tomorrow’s integration handoff](docs/TOMORROW.md) and the [step-by-step evaluation paths](evals/README.md).

Relay delegates broad source inspection to an isolated Copilot worker. The main agent receives source-backed findings instead of complete files. An optional writer generates a new file directly on disk.

Flightlog only distributes these components. Copilot CLI or Copilot Chat in an IDE invokes the scripts. Flightlog does not need to be running. There is no Relay service, installer, private virtual environment, or separate application to operate.

## Components

| Component | Install destination | Dependency |
| --- | --- | --- |
| Reader skill and shared scripts/references | `~/.copilot/skills/relay-reader/` | Existing Python and Copilot SDK |
| Optional writer skill | `~/.copilot/skills/relay-writer/` | Reader |
| Optional routing hook definition | `~/.copilot/hooks/relay-routing.json` | Reader and hook script below |
| Routing hook script | `~/.copilot/hooks/relay-routing/scripts/hook.py` | Reader scripts |

Keep each directory's accompanying files together. The routing component includes both its JSON definition and script directory. See [catalog integration](docs/CATALOG.md).

## Client support

| Client | Skills | Automatic read interception |
| --- | --- | --- |
| Copilot CLI | Supported | Hook integration supplied; verify loading locally |
| VS Code Copilot agent mode | Supported | Hooks are in preview; verify loading locally |
| IntelliJ Copilot agent mode | Skills are in preview | GitHub currently lists hooks as unsupported |

IntelliJ users can ask Copilot to use relay-reader explicitly. Skill selection is advisory. Relay cannot enforce interception where the host has no hook support. Plain chat without terminal/tool execution cannot run the scripts.

Sources checked September 10, 2026: [GitHub support matrix](https://docs.github.com/en/copilot/reference/customization-cheat-sheet), [VS Code hooks](https://code.visualstudio.com/docs/agent-customization/hooks).

## Tomorrow's integration steps

1. Add the three components to ai-component-catalog with the destinations above. Map dependencies using your existing catalog.json schema. Flightlog owns copying and removing the files.
2. Point `RELAY_PYTHON` at the absolute Python executable in Flightlog's existing venv. The IDE and CLI must inherit this setting; an environment variable set only inside Flightlog does not reach separately launched IDEs. Alternatively, have the skills invoke that interpreter directly. No Flightlog process is required. Use Python 3.11 or newer.
3. Inspect `skills/relay-reader/references/relay.json`. Replace `LUNA_MODEL_ID` in `model` with the actual Luna 5.6 ID from `doctor --live`. Leave `writer_model` null: ordinary code generation stays with the main agent. The optional writer requires a separately configured model and never inherits the reader model. For settings that survive component updates, set `RELAY_CONFIG` to an external JSON file with these keys.
4. In a terminal with the same environment as Copilot, run the commands below. The smoke check sends a small paid model request and activates routing only after a valid result.

```sh
python3 ~/.copilot/skills/relay-reader/scripts/run.py doctor --live
python3 ~/.copilot/skills/relay-reader/scripts/run.py doctor --smoke
```

5. Restart or reload the Copilot client. Confirm that relay-reader appears in its available skills. For VS Code, confirm the hook appears in its hook diagnostics. If needed, add `"~/.copilot/hooks": true` to the existing `chat.hookFilesLocations` map. Preserve other entries. Workspace hook precedence and client policy can affect loading.
6. Ask the agent: "Use relay-reader to inspect these files and identify the retry defaults, with evidence. Pass the paths directly; do not first read the files." Supply actual repository paths. Confirm that the script runs and only findings return.
7. In CLI and VS Code, attempt a native broad read of a text fixture with more than 350 lines. Confirm a Relay denial in host diagnostics, followed by skill delegation. A bounded read of 40 lines should pass. In IntelliJ, test explicit skill use instead.
8. Run `python3 evals/run_live.py --runner ~/.copilot/skills/relay-reader/scripts/run.py` from this bundle. This makes three paid reader calls. Review the results and the focused repository checks before broader rollout.

The SDK API was inspected and its session lifecycle exercised with github-copilot-sdk 1.0.13 and runtime 1.0.83. Relay does not install or upgrade either. If Flightlog's venv has a different API, adapt `skills/relay-reader/scripts/relay/worker.py` and repeat the smoke check. An IDE sign-in does not guarantee that the SDK runtime is authenticated; the live diagnostic checks that separately.

The hook launcher uses Python from PATH and only the standard library. If your managed machines do not expose it, change the static hook command to your existing venv executable. All model calls use the interpreter selected by the skill launcher.

## Why a separate worker session?

The user's conversation stays in Copilot CLI or the IDE. Its terminal tool starts the Relay script. The script starts a transient SDK runtime and creates an isolated worker session with the configured model. It reads the selected files directly and returns only validated findings. The worker session is then disconnected and deleted, and its runtime stops.

Separate model context is essential to this design. Changing the model inside the main conversation would leave the bulk files in that conversation. The SDK session is one implementation of isolation. A native subagent could replace it if the host provides the same control over model choice, context, tool access, and returned output. Relay uses the SDK for a consistent worker path across the supported clients.

## Operation and limits

The hook denies recognized broad reads and suggests the skill. It does not substitute tool results or start a worker itself. Bounded source reads remain available for debugging, editing, and checking findings. The reader also has an explicit `direct-read --path FILE --reason TEXT` exception when complete source is necessary.

The hook recognizes common file-read arguments and simple cat/head/tail/less/more commands. Complex shell expressions and unknown tools are left alone. This is cost routing, not an access-control boundary. Check the actual tool names and input shapes in each client before claiming coverage.

The worker has no tools, project instruction discovery, or persistent session store enabled. Relay validates evidence against the supplied source snapshot. This does not prove a finding's interpretation or completeness. Code generation requires review and repository tests. Source selection must respect the organization's data and content-exclusion rules; direct script reads do not automatically inherit every IDE exclusion setting.

Local state is stored in `~/.copilot/state/relay/`: readiness and optional counts/timings, without source or prompts in Relay's metrics. Session deletion is attempted and cleanup failures are reported. This is not a guarantee about provider retention or SDK diagnostic storage.

Set `mode` to `observe` to collect routing counts without denial, or `off` to disable it. Remove the marketplace hook toggle to stop interception. Changing the worker model or Relay version requires another smoke check. The default timeout is 120 seconds plus bounded cleanup; there is no claim that this matches Spotify's latency.

[Validation and limitations](docs/VALIDATION.md) · [Trial procedure](evals/README.md)

## Spotify source and model choice

The [published Spotify example](https://engineering.atspotify.com/2026/9/portal-by-spotify-cut-my-claude-code-token-usage-by-90) uses Gemini 2.5 Flash for both bulk-reader and predictable code-writer work. It leaves edits and reasoning with Claude; it does not identify that Claude model as Opus. Relay deliberately uses the team’s requested Luna reader tier and leaves code generation with the main agent by default. Small and targeted reads are not all delegated. Routing uses explicit rules, not an intelligent model selector.
