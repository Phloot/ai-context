import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "skills/relay-reader/scripts"))
import asyncio
import os
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from relay import config, worker


class FakeSession:
    def __init__(self, error=None):
        self.error = error
        self.aborted = False

    async def send_and_wait(self, prompt, *, timeout):
        self.prompt = prompt
        if self.error:
            raise self.error
        return SimpleNamespace(data=SimpleNamespace(content="worker response"))

    async def abort(self):
        self.aborted = True

    async def disconnect(self):
        self.disconnected = True


class FakeClient:
    def __init__(self, error=None, cleanup_error=False):
        self.session = FakeSession(error)
        self.cleanup_error = cleanup_error
        self.deleted = None

    async def start(self):
        pass

    async def stop(self):
        self.stopped = True

    async def force_stop(self):
        self.stopped = True

    async def create_session(self, **kwargs):
        self.options = kwargs
        return self.session

    async def delete_session(self, session_id):
        self.deleted = session_id
        if self.cleanup_error:
            raise RuntimeError("cleanup failed")


class WorkerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(patch.stopall)
        patch.dict(os.environ, {"COPILOT_HOME": self.temp.name}).start()
        self.settings = config.DEFAULTS.copy()

    def run_worker(self, client):
        return asyncio.run(worker.invoke("private source", worker.READER, self.settings, lambda _: client))

    def test_isolated_invocation_and_cleanup(self):
        client = FakeClient()
        text, metadata = self.run_worker(client)
        self.assertEqual(text, "worker response")
        self.assertEqual(client.options["available_tools"], [])
        for field in ("enable_skills", "enable_file_hooks", "enable_config_discovery", "enable_session_store"):
            self.assertFalse(client.options[field])
        self.assertEqual(client.options["hooks"]["on_pre_tool_use"]({}, {})["permissionDecision"], "deny")
        self.assertTrue(client.session.aborted)
        self.assertTrue(client.session.disconnected)
        self.assertTrue(client.deleted.startswith("relay-"))
        self.assertTrue(metadata["session_deleted"])
        log = (config.state_dir() / "metrics.jsonl").read_text()
        self.assertNotIn("private source", log)
        self.assertNotIn("worker response", log)

    def test_timeout_and_failure_still_abort_and_delete(self):
        for error in (TimeoutError(), RuntimeError("provider failed")):
            client = FakeClient(error)
            with self.assertRaises(type(error)):
                self.run_worker(client)
            self.assertTrue(client.session.aborted)
            self.assertIsNotNone(client.deleted)
            self.assertTrue(client.stopped)

    def test_cleanup_failure_is_reported(self):
        _, metadata = self.run_worker(FakeClient(cleanup_error=True))
        self.assertFalse(metadata["session_deleted"])

    def test_startup_is_inside_timeout_and_client_is_stopped(self):
        client = FakeClient()
        async def slow_start():
            await asyncio.sleep(1)
        client.start = slow_start
        self.settings["timeout_seconds"] = 0.02
        with self.assertRaises(TimeoutError):
            self.run_worker(client)
        self.assertTrue(client.stopped)
        self.assertFalse(hasattr(client, "options"))
