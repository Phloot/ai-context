import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "skills/relay-reader/scripts"))
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from relay.files import read_sources, validate_answer, write_new_file
from relay import cli, config


class FileTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "source.py").write_text("RETRIES = 3\nTIMEOUT = 10\n")
        self.sources = read_sources(["source.py"], self.root, 1000)

    def answer(self, **changes):
        finding = {"claim": "Retries default to three", "path": "source.py",
                   "start_line": 1, "end_line": 1, "evidence": "RETRIES = 3"}
        finding.update(changes)
        return json.dumps({"findings": [finding], "limitations": []})

    def test_evidence_is_verified_and_hash_attached(self):
        result = validate_answer(self.answer(), self.sources, 2000)
        self.assertEqual(result["findings"][0]["source_sha256"], self.sources[0]["sha256"])

    def test_rejects_invalid_evidence_and_locations(self):
        for changes in ({"path": "missing.py"}, {"start_line": 0}, {"end_line": 99},
                        {"evidence": "RETRIES = 4"}, {"evidence": ""}, {"start_line": True}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                validate_answer(self.answer(**changes), self.sources, 2000)

    def test_missing_context_is_valid_but_wrong_schema_is_not(self):
        text = json.dumps({"findings": [], "limitations": ["The caller is absent."]})
        self.assertEqual(validate_answer(text, self.sources, 2000)["findings"], [])
        for text in ('[]', '{"findings": [], "limitations": "unknown"}', 'not json'):
            with self.subTest(text=text), self.assertRaises(ValueError):
                validate_answer(text, self.sources, 2000)

    def test_input_is_bounded_and_deduplicated(self):
        self.assertEqual(len(read_sources(["source.py", "./source.py"], self.root, 1000)), 1)
        with self.assertRaises(ValueError):
            read_sources(["source.py"], self.root, 5)
        (self.root / "binary").write_bytes(b"hello\0world")
        with self.assertRaises(ValueError):
            read_sources(["binary"], self.root, 1000)

    def test_symlink_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as outside:
            path = Path(outside) / "secret"
            path.write_text("outside")
            try:
                (self.root / "link").symlink_to(path)
            except OSError:
                self.skipTest("Symlinks are unavailable")
            with self.assertRaises(ValueError):
                read_sources(["link"], self.root, 1000)

    def test_new_file_checks_syntax_and_preserves_existing_files(self):
        result = write_new_file("```python\nx = 1\n```", "new.py", self.root, 1000)
        self.assertTrue(result["review_required"])
        self.assertEqual((self.root / "new.py").read_text(), "x = 1\n")
        with self.assertRaises(ValueError):
            write_new_file("x = 2", "new.py", self.root, 1000)
        with self.assertRaises(SyntaxError):
            write_new_file("def invalid(", "bad.py", self.root, 1000)
        self.assertFalse((self.root / "bad.py").exists())

    def test_new_file_rejects_external_target_and_existing_symlink(self):
        with self.assertRaises(ValueError):
            write_new_file("x=1", "../outside.py", self.root, 1000)
        try:
            (self.root / "alias.py").symlink_to(self.root / "nonexistent.py")
        except OSError:
            self.skipTest("Symlinks are unavailable")
        with self.assertRaises(ValueError):
            write_new_file("x=1", "alias.py", self.root, 1000)

    def test_invalid_target_never_calls_worker(self):
        for target in ("../outside.py", "missing/new.py", "source.py"):
            args = cli.parser().parse_args(["write", "--spec", "x=1", "--reference", "source.py",
                                           "--target", target, "--root", str(self.root)])
            with patch("relay.cli.run_worker") as invoke, self.assertRaises(ValueError):
                cli.delegate(args, {**config.DEFAULTS, "writer_model": "frontier-test"})
            invoke.assert_not_called()

    def test_writer_never_inherits_reader_model(self):
        from relay import cli, config
        from unittest.mock import patch
        args = cli.parser().parse_args(["write", "--spec", "x=1", "--reference", "source.py",
                                       "--target", "new.py", "--root", str(self.root)])
        with patch.object(cli, "run_worker") as worker:
            with self.assertRaisesRegex(ValueError, "writer is disabled"):
                cli.delegate(args, config.DEFAULTS.copy())
            worker.assert_not_called()
        with patch.object(cli, "run_worker", return_value=("x=1", {"session_deleted": True})) as worker:
            cli.delegate(args, {**config.DEFAULTS, "writer_model": "frontier-test", "log_metrics": False})
            self.assertEqual(worker.call_args.args[2]["model"], "frontier-test")
