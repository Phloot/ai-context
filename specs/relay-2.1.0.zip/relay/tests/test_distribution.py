"""Check the installed layout independently of the source import path."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class DistributionTests(unittest.TestCase):
    def test_copied_launchers_and_static_hook(self):
        with tempfile.TemporaryDirectory(prefix="relay home ") as directory:
            home = Path(directory)
            for folder in ("skills", "hooks"):
                shutil.copytree(ROOT / folder, home / folder)
            env = {**os.environ, "COPILOT_HOME": str(home), "RELAY_PYTHON": sys.executable,
                   "RELAY_CONFIG": str(home / "settings.json"), "RELAY_WORKER": "0"}
            for skill in ("relay-reader", "relay-writer"):
                result = subprocess.run([sys.executable, str(home / "skills" / skill / "scripts/run.py"), "--version"],
                                        env=env, capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertEqual(result.stdout.strip(), "2.1.0")
            state = home / "state/relay"
            state.mkdir(parents=True)
            (state / "ready.json").write_text(json.dumps({"model": "LUNA_MODEL_ID", "relay": "2.1.0"}))
            (home / "large.py").write_text("x = 1\n" * 351)
            descriptor = json.loads((home / "hooks/relay-routing.json").read_text())
            command = descriptor["hooks"]["PreToolUse"][0]["bash"]
            for tool, args in (("Read", {"file_path": "large.py"}),
                               ("read_file", {"filePath": "large.py", "startLine": 1, "endLine": 351})):
                event = {"cwd": str(home), "tool_name": tool, "tool_input": args}
                result = subprocess.run(["bash", "-c", command], input=json.dumps(event), env=env,
                                        capture_output=True, text=True)
                self.assertEqual(result.returncode, 0, result.stderr)
                output = json.loads(result.stdout)
                self.assertEqual(output["permissionDecision"], "deny")
                self.assertEqual(output["hookSpecificOutput"]["permissionDecision"], "deny")
                self.assertEqual(output["hookSpecificOutput"]["hookEventName"], "PreToolUse")
            event["tool_input"]["endLine"] = 40
            result = subprocess.run(["bash", "-c", command], input=json.dumps(event), env=env,
                                    capture_output=True, text=True)
            self.assertEqual(json.loads(result.stdout), {})
            shutil.rmtree(home / "skills/relay-reader")
            result = subprocess.run(["bash", "-c", command], input=json.dumps(event), env=env,
                                    capture_output=True, text=True)
            self.assertEqual(json.loads(result.stdout), {})
