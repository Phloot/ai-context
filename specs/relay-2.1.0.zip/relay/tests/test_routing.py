import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "skills/relay-reader/scripts"))
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from relay import config, routing

ROOT = Path(__file__).resolve().parents[1]


class RoutingTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.addCleanup(patch.stopall)
        patch.dict(os.environ, {"COPILOT_HOME": str(self.root / "home"), "RELAY_WORKER": "0", "RELAY_CONFIG": str(self.root / "config.json")}).start()
        self.settings = config.DEFAULTS.copy()
        config.save(self.settings)
        config.mark_ready(self.settings)
        (self.root / "large file.py").write_text("x = 1\n" * 351)
        (self.root / "small.py").write_text("x = 1\n" * 350)

    def event(self, name="view", **args):
        return {"toolName": name, "toolArgs": args or {"path": "large file.py"}, "cwd": str(self.root)}

    def test_full_read_redirects_but_boundary_and_bounded_reads_pass(self):
        self.assertEqual(routing.decide(self.event(), self.settings)["permissionDecision"], "deny")
        for args in ({"path": "small.py"}, {"path": "large file.py", "view_range": [1, 40]},
                     {"file_path": "large file.py", "offset": 1, "limit": 40}):
            self.assertEqual(routing.decide(self.event(**args), self.settings), {})

    def test_offset_and_unbounded_ranges_do_not_bypass(self):
        for args in ({"offset": 1}, {"view_range": [1, -1]}, {"view_range": [1, 351]}):
            args["path"] = "large file.py"
            self.assertEqual(routing.decide(self.event(**args), self.settings)["permissionDecision"], "deny")

    def test_modes_and_readiness(self):
        for mode in ("off", "observe"):
            self.assertEqual(routing.decide(self.event(), {**self.settings, "mode": mode}), {})
        self.assertEqual(routing.decide(self.event(), {**self.settings, "model": "different-model"}), {})
        with patch.dict(os.environ, {"RELAY_WORKER": "1"}):
            self.assertEqual(routing.decide(self.event(), self.settings), {})

    def test_shell_reads_and_targeted_commands(self):
        for command in ('cat "large file.py"', 'head -n 400 "large file.py"', 'tail --lines=400 "large file.py"'):
            result = routing.decide(self.event("bash", command=command), self.settings)
            self.assertEqual(result["permissionDecision"], "deny", command)
        for command in ('head "large file.py"', 'tail -n 10 "large file.py"',
                        'cat "large file.py" | grep x', 'python tool.py', 'cat --unknown "large file.py"'):
            self.assertEqual(routing.decide(self.event("bash", command=command), self.settings), {}, command)

    def test_both_payload_formats_and_string_args(self):
        event = {"tool_name": "Read", "tool_input": json.dumps({"file_path": "large file.py"}), "cwd": str(self.root)}
        self.assertEqual(routing.decide(event, self.settings)["permissionDecision"], "deny")

    def test_hook_process_defers_on_malformed_input_and_bad_config(self):
        for value in ("invalid JSON", "null", '{"toolName":"view","toolArgs":"invalid"}'):
            result = subprocess.run([sys.executable, str(ROOT / "hooks/relay-routing/scripts/hook.py")], input=value,
                                    text=True, capture_output=True)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(json.loads(result.stdout), {})
        (config.config_path()).write_text("{bad")
        result = subprocess.run([sys.executable, str(ROOT / "hooks/relay-routing/scripts/hook.py")], input=json.dumps(self.event()),
                                text=True, capture_output=True)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(json.loads(result.stdout), {})

    def test_unknown_tools_missing_files_and_edits_are_untouched(self):
        for event in (self.event("edit"), self.event("mcp_read"), self.event(path="missing")):
            self.assertEqual(routing.decide(event, self.settings), {})
